import 'package:flutter/material.dart';
import 'app/app_state.dart';
import 'theme/app_theme.dart';
import 'screens/welcome_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final appState = AppState();
  runApp(UniStepApp(appState: appState));
}

class UniStepApp extends StatelessWidget {
  final AppState appState;

  const UniStepApp({super.key, required this.appState});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appState,
      builder: (context, _) {
        return MaterialApp(
          title: 'UNI STEP',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.lightTheme,
          home: WelcomeScreen(appState: appState),
        );
      },
    );
  }
}
