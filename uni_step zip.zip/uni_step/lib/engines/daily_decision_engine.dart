import '../models/task_item.dart';
import '../models/decision_item.dart';
import '../models/student_profile.dart';

class DailyDecisionEngine {
  /// Evaluates feasible tasks given current context, enforces hard constraints,
  /// scores using multi-attribute utility theory, and returns the single best recommendation.
  static DecisionItem evaluateNextAction({
    required List<TaskItem> tasks,
    required StudentProfile profile,
    int? overrideAvailableMinutes,
    String? overrideLocation,
    String? overrideAcademicPriority,
    String? previousRecommendationTitle,
  }) {
    final availableMinutes = overrideAvailableMinutes ?? profile.currentAvailableMinutes;
    final location = overrideLocation ?? profile.currentLocation;
    final academicPriority = overrideAcademicPriority ?? profile.academicPriority;

    // Weight adjustments based on user's priority setting
    double weightUrgency = 0.30;
    double weightImpact = 0.25;
    double weightExam = 0.20;
    double weightTimeFit = 0.15;
    double weightTravel = 0.10;

    if (academicPriority == 'High') {
      weightUrgency = 0.35;
      weightImpact = 0.30;
      weightExam = 0.25;
      weightTimeFit = 0.05;
      weightTravel = 0.05;
    } else if (academicPriority == 'Balanced') {
      weightUrgency = 0.25;
      weightImpact = 0.25;
      weightExam = 0.20;
      weightTimeFit = 0.15;
      weightTravel = 0.15;
    }

    // Step 1: Filter feasible tasks by Hard Constraints
    // Hard constraint 1: Total time required (task duration + travel time) <= available time + buffer (15 min leeway)
    final feasibleTasks = <_ScoredCandidate>[];

    for (final task in tasks) {
      final totalTimeNeeded = task.durationMinutes + task.travelTimeMinutes;

      // Hard constraint check: if available time is significantly smaller than needed
      if (totalTimeNeeded > availableMinutes + 15) {
        // Excluded by hard constraint: time infeasible
        continue;
      }

      // Calculate factor scores (normalized between 0.0 and 1.0)
      
      // 1. Deadline urgency (closer deadline = higher score)
      double urgency = 0.0;
      if (task.deadlineHoursLeft <= 6.0) {
        urgency = 0.95; // Due tonight / urgent
      } else if (task.deadlineHoursLeft <= 24.0) {
        urgency = 0.85;
      } else if (task.deadlineHoursLeft <= 72.0) {
        urgency = 0.65;
      } else {
        urgency = 0.40;
      }

      // 2. Academic impact (from 0 to 100)
      final impact = (task.academicImpact / 100.0).clamp(0.0, 1.0);

      // 3. Exam proximity (closer exam in days = higher score)
      double examScore = 0.0;
      if (task.examProximityDays <= 3) {
        examScore = 0.90;
      } else if (task.examProximityDays <= 7) {
        examScore = 0.70;
      } else {
        examScore = 0.35;
      }

      // 4. Time fit: how well task duration matches available time
      // Perfect fit is when task utilizes 70% to 95% of available time
      final timeRatio = task.durationMinutes / availableMinutes.toDouble();
      double timeFit = 0.50;
      if (timeRatio >= 0.60 && timeRatio <= 1.05) {
        timeFit = 0.92;
      } else if (timeRatio < 0.60) {
        timeFit = 0.70; // leaves too much unused time or too small
      } else {
        timeFit = 0.55;
      }

      // 5. Travel efficiency (closer location = higher score)
      double travelScore = 0.85;
      if (task.travelTimeMinutes <= 3) {
        travelScore = 0.95;
      } else if (task.travelTimeMinutes <= 7) {
        travelScore = 0.85;
      } else {
        travelScore = 0.65;
      }

      // If user is already at the location
      if (location.toLowerCase() == task.locationName.toLowerCase()) {
        travelScore = 1.0;
      }

      // Calculate composite score (0 to 100)
      final rawScore = (urgency * weightUrgency) +
          (impact * weightImpact) +
          (examScore * weightExam) +
          (timeFit * weightTimeFit) +
          (travelScore * weightTravel);

      final totalScore = (rawScore * 100.0).clamp(0.0, 99.0);

      feasibleTasks.add(
        _ScoredCandidate(
          task: task,
          totalScore: totalScore,
          urgency: urgency,
          impact: impact,
          examScore: examScore,
          timeFit: timeFit,
          travelScore: travelScore,
        ),
      );
    }

    // If no task fits (e.g. available time is very small like 15 mins), fallback to the shortest task
    if (feasibleTasks.isEmpty) {
      final shortestTask = tasks.reduce((a, b) => a.durationMinutes < b.durationMinutes ? a : b);
      feasibleTasks.add(
        _ScoredCandidate(
          task: shortestTask,
          totalScore: 50.0,
          urgency: 0.5,
          impact: 0.5,
          examScore: 0.5,
          timeFit: 0.5,
          travelScore: 0.8,
        ),
      );
    }

    // Sort descending by score
    feasibleTasks.sort((a, b) => b.totalScore.compareTo(a.totalScore));

    final best = feasibleTasks.first;
    final alternatives = feasibleTasks.skip(1).map((c) => c.task).toList();

    // Visual breakdown factors
    final factors = [
      DecisionFactor(
        label: 'Deadline urgency',
        score: best.urgency,
        description: best.task.deadlineHoursLeft <= 6
            ? 'Due tonight (${best.task.dueText})'
            : 'Sufficient submission window available',
      ),
      DecisionFactor(
        label: 'Academic impact',
        score: best.impact,
        description: 'High credit weight in ${best.task.courseCode}',
      ),
      DecisionFactor(
        label: 'Exam relevance',
        score: best.examScore,
        description: best.task.examProximityDays <= 3
            ? 'Major exam in ${best.task.examProximityDays} days directly reinforces this'
            : 'Exam is scheduled in future weeks',
      ),
      DecisionFactor(
        label: 'Time fit',
        score: best.timeFit,
        description: '${best.task.durationMinutes} mins fits cleanly inside your ${availableMinutes} mins window',
      ),
      DecisionFactor(
        label: 'Travel efficiency',
        score: best.travelScore,
        description: '${best.task.locationName} is only ${best.task.travelTimeMinutes} mins away',
      ),
    ];

    // Generate specific bullet-point reasons
    final reasons = <String>[];
    if (best.task.deadlineHoursLeft <= 6) {
      reasons.add('Deadline is approaching (${best.task.dueText})');
    }
    if (best.task.completionPercent > 0) {
      reasons.add('${best.task.completionPercent}% already completed — low friction to wrap up');
    }
    if (best.task.examProximityDays <= 3) {
      reasons.add('Midterm exam is in only ${best.task.examProximityDays} days; this covers core questions');
    }
    reasons.add('You currently have ${availableMinutes} mins available (task takes ${best.task.durationMinutes} mins)');
    reasons.add('${best.task.locationName} is ${best.task.travelTimeMinutes} minutes away from your current location');
    reasons.add('Completing it now completely clears your evening workload');

    // Trade-off analysis
    String tradeOff;
    if (best.task.title.contains('DBMS') && availableMinutes <= 90) {
      tradeOff =
          'You may miss part of the 5:30 PM AI Club workshop if you stay longer, but you will eliminate high-stakes deadline risk before tomorrow.';
    } else if (best.task.title.contains('Revise')) {
      tradeOff =
          'Focuses on immediate exam concept recall rather than assignment submission, which must still be finished later today.';
    } else {
      tradeOff =
          'Allocates your available block to deep work rather than campus leisure or spontaneous social activities.';
    }

    final gains = [
      'Zero deadline penalty risk on academic submissions',
      'Direct reinforcement for the upcoming midterm exam',
      'Significantly lower stress for the remainder of the week',
    ];

    final giveUps = [
      'Extracurricular leisure and club networking time',
      'Unstructured free time in the cafeteria',
    ];

    // Generate What-If change explanation if applicable
    String changeReason = '';
    if (previousRecommendationTitle != null && previousRecommendationTitle != best.task.title) {
      if (availableMinutes <= 45) {
        changeReason =
            'Your available time decreased to $availableMinutes minutes. The full 60-min assignment would cause a schedule breach, so UNI STEP shifted to a high-yield 35-min exam revision.';
      } else if (availableMinutes >= 150) {
        changeReason =
            'Your available time expanded to $availableMinutes minutes (2.5+ hours). You can now finish the assignment with ample buffer to attend the AI Club workshop.';
      } else {
        changeReason =
            'Decision recalculated based on updated context: time constraint of $availableMinutes mins and $academicPriority academic priority.';
      }
    }

    final contextSummary =
        '$availableMinutes mins free • ${best.task.locationName} • $academicPriority Academic Priority';

    return DecisionItem(
      id: 'dec_${DateTime.now().millisecondsSinceEpoch}',
      recommendedTask: best.task,
      totalScore: best.totalScore,
      factors: factors,
      reasons: reasons,
      tradeOff: tradeOff,
      gains: gains,
      giveUps: giveUps,
      alternatives: alternatives,
      timestamp: DateTime.now(),
      contextSummary: contextSummary,
      changeReason: changeReason,
    );
  }
}

class _ScoredCandidate {
  final TaskItem task;
  final double totalScore;
  final double urgency;
  final double impact;
  final double examScore;
  final double timeFit;
  final double travelScore;

  _ScoredCandidate({
    required this.task,
    required this.totalScore,
    required this.urgency,
    required this.impact,
    required this.examScore,
    required this.timeFit,
    required this.travelScore,
  });
}
