import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../utils/constants.dart';

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terms & Conditions'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primaryContainer.withOpacity(0.5),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.primaryLight.withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.gavel, color: AppColors.primary, size: 24),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'UNI STEP Academic Decision Support Agreement',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.onPrimaryContainer,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. Acceptance of Terms',
              content:
                  'By accessing or using UNI STEP ("the Platform"), you agree to be bound by these Terms and Conditions. If you do not agree, you may not access or use the service.',
            ),
            _buildSection(
              title: '2. Purpose of UNI STEP',
              content:
                  'UNI STEP is designed to consolidate academic, timetable, and campus context to assist students in prioritizing daily actions and evaluating career specializations. It acts as an advisory utility.',
            ),
            _buildSection(
              title: '3. Important Disclaimer — No Outcome Guarantee',
              content:
                  AppConstants.disclaimerText +
                      '\n\nUNI STEP recommendations do NOT guarantee academic grades, placement offers, internship selection, employment, or salary levels. All scores and timelines are advisory models.',
              isHighlight: true,
            ),
            _buildSection(
              title: '4. User Responsibility',
              content:
                  'Students remain solely responsible for meeting university deadlines, attending mandatory classes, submitting verified assignments, and validating all curriculum decisions with official university counselors.',
            ),
            _buildSection(
              title: '5. Account Security & Privacy',
              content:
                  'You are responsible for safeguarding your credentials. UNI STEP does not share your private schedule or academic performance with other students.',
            ),
            _buildSection(
              title: '6. Contact & Support',
              content:
                  'For inquiries regarding UNI STEP terms or algorithm feedback, contact: team@unistep.app',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content, bool isHighlight = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: isHighlight ? const EdgeInsets.all(12) : EdgeInsets.zero,
            decoration: isHighlight
                ? BoxDecoration(
                    color: AppColors.warningContainer.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.warning.withOpacity(0.5)),
                  )
                : null,
            child: Text(
              content,
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                color: isHighlight ? const Color(0xFF92400E) : AppColors.textSecondary,
                fontWeight: isHighlight ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
