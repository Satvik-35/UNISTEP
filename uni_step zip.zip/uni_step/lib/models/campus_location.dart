class CampusLocation {
  final String id;
  final String name;
  final String category;
  final int travelTimeMinutes;
  final double x; // Relative layout position (0.0 to 1.0) for interactive map
  final double y;
  final String description;
  final String iconName;

  const CampusLocation({
    required this.id,
    required this.name,
    required this.category,
    required this.travelTimeMinutes,
    required this.x,
    required this.y,
    required this.description,
    required this.iconName,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'travelTimeMinutes': travelTimeMinutes,
      'x': x,
      'y': y,
      'description': description,
      'iconName': iconName,
    };
  }

  factory CampusLocation.fromMap(Map<String, dynamic> map) {
    return CampusLocation(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      category: map['category'] ?? '',
      travelTimeMinutes: map['travelTimeMinutes']?.toInt() ?? 5,
      x: (map['x'] as num?)?.toDouble() ?? 0.5,
      y: (map['y'] as num?)?.toDouble() ?? 0.5,
      description: map['description'] ?? '',
      iconName: map['iconName'] ?? 'place',
    );
  }
}
