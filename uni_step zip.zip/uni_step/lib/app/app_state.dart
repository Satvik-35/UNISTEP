import 'package:flutter/foundation.dart';
import '../models/student_profile.dart';
import '../models/task_item.dart';
import '../models/decision_item.dart';
import '../models/specialization_model.dart';
import '../models/campus_location.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/gemini_service.dart';
import '../services/maps_service.dart';
import '../engines/daily_decision_engine.dart';
import '../engines/specialization_engine.dart';
import '../data/demo_data.dart';

class AppState extends ChangeNotifier {
  final AuthService authService = MockAuthService();
  final FirestoreService firestoreService = MockFirestoreService();
  final GeminiService geminiService = MockGeminiService();
  final MapsService mapsService = MockCampusMapsService();

  StudentProfile _profile = DemoData.rahulProfile;
  List<TaskItem> _tasks = List.from(DemoData.initialTasks);
  List<CampusLocation> _locations = List.from(DemoData.campusLocations);
  List<DecisionItem> _history = [];

  DecisionItem? _currentDecision;
  SpecializationProfile _specializationProfile = SpecializationProfile();
  List<SpecializationOption> _specializationResults = [];
  SpecializationOption? _selectedSpecialization;

  bool _isLoading = false;
  String? _errorMessage;

  AppState() {
    _initialize();
  }

  StudentProfile get profile => _profile;
  List<TaskItem> get tasks => _tasks;
  List<CampusLocation> get locations => _locations;
  List<DecisionItem> get history => _history;
  DecisionItem? get currentDecision => _currentDecision;
  SpecializationProfile get specializationProfile => _specializationProfile;
  List<SpecializationOption> get specializationResults => _specializationResults;
  SpecializationOption? get selectedSpecialization => _selectedSpecialization;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  void _initialize() {
    // Generate initial decision for Rahul (DBMS assignment)
    recalculateDailyDecision();
    // Evaluate initial specialization
    evaluateSpecialization();
  }

  void recalculateDailyDecision({
    int? overrideAvailableMinutes,
    String? overrideLocation,
    String? overrideAcademicPriority,
  }) {
    final previousTitle = _currentDecision?.recommendedTask.title;
    _currentDecision = DailyDecisionEngine.evaluateNextAction(
      tasks: _tasks,
      profile: _profile,
      overrideAvailableMinutes: overrideAvailableMinutes,
      overrideLocation: overrideLocation,
      overrideAcademicPriority: overrideAcademicPriority,
      previousRecommendationTitle: previousTitle,
    );

    // Record into history
    if (_currentDecision != null) {
      _history.insert(0, _currentDecision!);
    }
    notifyListeners();
  }

  void evaluateSpecialization() {
    _specializationResults = SpecializationEngine.evaluateSpecializations(
      profile: _specializationProfile,
    );
    if (_specializationResults.isNotEmpty) {
      _selectedSpecialization = _specializationResults.first;
    }
    notifyListeners();
  }

  void updateSpecializationPriorities({
    required int interest,
    required int salary,
    required int flexibility,
    required int research,
  }) {
    _specializationProfile.priorityInterest = interest;
    _specializationProfile.prioritySalary = salary;
    _specializationProfile.priorityFlexibility = flexibility;
    _specializationProfile.priorityResearch = research;

    evaluateSpecialization();
  }

  void setSelectedSpecialization(SpecializationOption option) {
    _selectedSpecialization = option;
    notifyListeners();
  }

  Future<bool> login(String usernameOrEmail, String password) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _profile = await authService.signInWithCredentials(usernameOrEmail, password);
      recalculateDailyDecision();
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> loginWithDemo() async {
    _isLoading = true;
    notifyListeners();
    _profile = await authService.signInWithDemo();
    recalculateDailyDecision();
    evaluateSpecialization();
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> register({
    required String name,
    required String username,
    required String email,
    required String password,
    String? university,
    String? year,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _profile = await authService.registerUser(
        name: name,
        username: username,
        email: email,
        password: password,
        university: university,
        year: year,
      );
      recalculateDailyDecision();
      evaluateSpecialization();
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  void updateProfile({
    required String name,
    required String university,
    required String year,
    required double cgpa,
  }) {
    _profile.name = name;
    _profile.university = university;
    _profile.year = year;
    _profile.cgpa = cgpa;
    recalculateDailyDecision();
    notifyListeners();
  }

  void markTaskCompleted(String taskId) {
    _tasks = _tasks.where((t) => t.id != taskId).toList();
    recalculateDailyDecision();
    notifyListeners();
  }
}
