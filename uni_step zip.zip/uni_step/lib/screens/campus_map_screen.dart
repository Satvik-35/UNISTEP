import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../app/app_state.dart';
import '../models/campus_location.dart';
import '../widgets/campus_map_widget.dart';

class CampusMapScreen extends StatefulWidget {
  final AppState appState;

  const CampusMapScreen({super.key, required this.appState});

  @override
  State<CampusMapScreen> createState() => _CampusMapScreenState();
}

class _CampusMapScreenState extends State<CampusMapScreen> {
  CampusLocation? _selectedLocation;

  @override
  void initState() {
    super.initState();
    // Default to the task's location or Central Library
    final taskLocName = widget.appState.currentDecision?.recommendedTask.locationName;
    _selectedLocation = widget.appState.locations.firstWhere(
      (l) => l.name.toLowerCase() == (taskLocName ?? '').toLowerCase(),
      orElse: () => widget.appState.locations[1], // Central Library
    );
  }

  @override
  Widget build(BuildContext context) {
    final profile = widget.appState.profile;
    final task = widget.appState.currentDecision?.recommendedTask;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('CAMPUS WAYFINDING'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current Location & Destination Info Ribbon
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.my_location, color: AppColors.secondary, size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'You are currently at:',
                          style: TextStyle(fontSize: 11, color: AppColors.textMuted, fontWeight: FontWeight.w600),
                        ),
                        Text(
                          profile.currentLocation,
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.secondaryContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      'Live GPS Beacon',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFF0F766E)),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // INTERACTIVE CAMPUS MAP CANVAS
            CampusMapWidget(
              locations: widget.appState.locations,
              selectedLocation: _selectedLocation,
              currentLocationId: 'loc_ab3',
              onSelectLocation: (loc) {
                setState(() => _selectedLocation = loc);
              },
            ),
            const SizedBox(height: 16),

            // SELECTED LOCATION DETAILS & DECISION ENGINE INTEGRATION
            if (_selectedLocation != null) ...[
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: AppColors.primary.withOpacity(0.3), width: 1.5),
                  boxShadow: [
                    BoxShadow(color: AppColors.primary.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, 3)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _selectedLocation!.name,
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                              ),
                              Text(
                                '${_selectedLocation!.category} Facility',
                                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primaryContainer,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.directions_walk, size: 16, color: AppColors.primary),
                              const SizedBox(width: 4),
                              Text(
                                '${_selectedLocation!.travelTimeMinutes} min walk',
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.primary),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _selectedLocation!.description,
                      style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 14),

                    // Contextual Decision Hook
                    if (task != null && task.locationName.toLowerCase() == _selectedLocation!.name.toLowerCase()) ...[
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0FDF4),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.success.withOpacity(0.4)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.check_circle, size: 16, color: AppColors.success),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Recommended action "${task.title}" is located here.',
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF166534)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                    ],

                    ElevatedButton.icon(
                      onPressed: () {
                        widget.appState.recalculateDailyDecision(
                          overrideLocation: _selectedLocation!.name,
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            backgroundColor: AppColors.primary,
                            content: Text('Updated current origin to ${_selectedLocation!.name} — decision refreshed!'),
                          ),
                        );
                      },
                      icon: const Icon(Icons.near_me, size: 18),
                      label: Text('Set as My Current Location & Recalculate'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        minimumSize: const Size(double.infinity, 46),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 20),

            // CAMPUS LOCATIONS DIRECTORY LIST
            const Text(
              'CAMPUS DESTINATIONS & WALKING TIMES',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 0.5, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 10),
            ...widget.appState.locations.map((loc) {
              final isChosen = _selectedLocation?.id == loc.id;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: isChosen ? AppColors.primaryContainer.withOpacity(0.4) : Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: isChosen ? AppColors.primary : AppColors.border),
                ),
                child: ListTile(
                  dense: true,
                  leading: CircleAvatar(
                    backgroundColor: AppColors.surfaceVariant,
                    child: Text('${loc.travelTimeMinutes}m', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                  ),
                  title: Text(loc.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                  subtitle: Text('${loc.category} • ${loc.description}', maxLines: 1, overflow: TextOverflow.ellipsis),
                  trailing: const Icon(Icons.chevron_right, size: 18),
                  onTap: () => setState(() => _selectedLocation = loc),
                ),
              );
            }),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
