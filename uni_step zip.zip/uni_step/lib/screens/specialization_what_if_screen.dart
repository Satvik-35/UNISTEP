import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../app/app_state.dart';
import '../models/specialization_model.dart';
import '../engines/specialization_engine.dart';
import 'career_roadmap_screen.dart';

class SpecializationWhatIfScreen extends StatefulWidget {
  final AppState appState;

  const SpecializationWhatIfScreen({super.key, required this.appState});

  @override
  State<SpecializationWhatIfScreen> createState() => _SpecializationWhatIfScreenState();
}

class _SpecializationWhatIfScreenState extends State<SpecializationWhatIfScreen> {
  late int _interest;
  late int _salary;
  late int _flexibility;
  late int _research;
  late int _international;
  List<SpecializationOption> _simulatedResults = [];
  String _whatIfChangeReason = '';

  @override
  void initState() {
    super.initState();
    final p = widget.appState.specializationProfile;
    _interest = p.priorityInterest;
    _salary = p.prioritySalary;
    _flexibility = p.priorityFlexibility;
    _research = p.priorityResearch;
    _international = p.priorityInternational;
    _runSimulation();
  }

  void _runSimulation() {
    final tempProfile = SpecializationProfile(
      cgpa: widget.appState.specializationProfile.cgpa,
      strongestSubjects: widget.appState.specializationProfile.strongestSubjects,
      weakestSubjects: widget.appState.specializationProfile.weakestSubjects,
      enjoyedSubjects: widget.appState.specializationProfile.enjoyedSubjects,
      languages: widget.appState.specializationProfile.languages,
      dsaKnowledge: widget.appState.specializationProfile.dsaKnowledge,
      mathComfort: widget.appState.specializationProfile.mathComfort,
      statsComfort: widget.appState.specializationProfile.statsComfort,
      interests: widget.appState.specializationProfile.interests,
      desiredRole: widget.appState.specializationProfile.desiredRole,
      priorityInterest: _interest,
      prioritySalary: _salary,
      priorityFlexibility: _flexibility,
      priorityResearch: _research,
      priorityInternational: _international,
    );

    final results = SpecializationEngine.evaluateSpecializations(profile: tempProfile);

    String reason;
    if (_flexibility >= 4 && results.first.title.contains('Software')) {
      reason =
          'Your recommendation changed to Software Engineering because you increased the priority of Career Flexibility. Software Engineering permits broad mobility across product, fintech, and web infrastructure.';
    } else if (_research >= 4 && results.first.title.contains('AI')) {
      reason =
          'AI / Machine Learning strongly solidified at the top because of your high Research weight, directly supported by your Linear Algebra and mathematical foundation.';
    } else if (_salary >= 5) {
      reason =
          'High compensation emphasis boosts high-demand product engineering tracks while evaluating verified entry-level roles.';
    } else {
      reason =
          'Specialization weights rebalanced across Interest ($_interest/5), Salary ($_salary/5), and Flexibility ($_flexibility/5).';
    }

    setState(() {
      _simulatedResults = results;
      _whatIfChangeReason = reason;
    });
  }

  @override
  Widget build(BuildContext context) {
    final top = _simulatedResults.isNotEmpty ? _simulatedResults.first : null;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('WHAT-IF: SPECIALIZATION'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppColors.specializationGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.tune, color: Colors.white, size: 26),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Tweak your decision drivers to see how your recommended track shifts dynamically.',
                      style: TextStyle(color: Colors.white, fontSize: 13, height: 1.3),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Priority Sliders Box
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  _buildSlider('Interest & Passion', _interest, (v) {
                    _interest = v;
                    _runSimulation();
                  }),
                  const Divider(height: 14),
                  _buildSlider('Salary Potential', _salary, (v) {
                    _salary = v;
                    _runSimulation();
                  }),
                  const Divider(height: 14),
                  _buildSlider('Career Pathway Flexibility', _flexibility, (v) {
                    _flexibility = v;
                    _runSimulation();
                  }),
                  const Divider(height: 14),
                  _buildSlider('Research & Academic Publishing', _research, (v) {
                    _research = v;
                    _runSimulation();
                  }),
                  const Divider(height: 14),
                  _buildSlider('International Relocation', _international, (v) {
                    _international = v;
                    _runSimulation();
                  }),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // SIMULATED RESULT CARD
            if (top != null) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.accent, width: 2),
                  boxShadow: [
                    BoxShadow(color: AppColors.accent.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.accentLight.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            'RECALCULATED RECOMMENDATION',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF6D28D9),
                            ),
                          ),
                        ),
                        Text(
                          '${top.matchPercentage}% Match',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.accent),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      top.title,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      top.summaryExplanation,
                      style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 16),

                    // YOUR RECOMMENDATION CHANGED BECAUSE... BANNER
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFAF5FF),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.accentLight),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.auto_awesome, color: AppColors.accent, size: 16),
                              SizedBox(width: 6),
                              Text(
                                'YOUR RECOMMENDATION CHANGED BECAUSE...',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF581C87),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            _whatIfChangeReason,
                            style: const TextStyle(fontSize: 13, height: 1.4, color: Color(0xFF4A044E)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),

                    ElevatedButton(
                      onPressed: () {
                        widget.appState.updateSpecializationPriorities(
                          interest: _interest,
                          salary: _salary,
                          flexibility: _flexibility,
                          research: _research,
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            backgroundColor: AppColors.accent,
                            content: Text('Updated active specialization priorities!'),
                          ),
                        );
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        minimumSize: const Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Save & Apply These Priorities', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildSlider(String label, int value, ValueChanged<int> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            Text('$value / 5', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.accent)),
          ],
        ),
        Slider(
          value: value.toDouble(),
          min: 1,
          max: 5,
          divisions: 4,
          activeColor: AppColors.accent,
          onChanged: (v) => onChanged(v.round()),
        ),
      ],
    );
  }
}
