import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../app/app_state.dart';
import '../models/specialization_model.dart';
import 'specialization_result_screen.dart';

class SpecializationQuestionnaireScreen extends StatefulWidget {
  final AppState appState;

  const SpecializationQuestionnaireScreen({super.key, required this.appState});

  @override
  State<SpecializationQuestionnaireScreen> createState() => _SpecializationQuestionnaireScreenState();
}

class _SpecializationQuestionnaireScreenState extends State<SpecializationQuestionnaireScreen> {
  int _currentStep = 0;
  late SpecializationProfile _profile;

  @override
  void initState() {
    super.initState();
    _profile = widget.appState.specializationProfile;
  }

  void _finishAssessment() {
    widget.appState.evaluateSpecialization();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => SpecializationResultScreen(appState: widget.appState)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('SPECIALIZATION ASSESSMENT'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Step Progress Indicator
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              color: Colors.white,
              child: Row(
                children: [
                  _buildStepPill(0, 'Academic'),
                  _buildStepDivider(0),
                  _buildStepPill(1, 'Technical'),
                  _buildStepDivider(1),
                  _buildStepPill(2, 'Interests'),
                  _buildStepDivider(2),
                  _buildStepPill(3, 'Preferences'),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.border),

            // Form Content based on current step
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: _buildStepContent(),
              ),
            ),

            // Navigation Bottom Bar
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: AppColors.border)),
              ),
              child: Row(
                children: [
                  if (_currentStep > 0) ...[
                    OutlinedButton(
                      onPressed: () => setState(() => _currentStep--),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Back'),
                    ),
                    const SizedBox(width: 12),
                  ],
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        if (_currentStep < 3) {
                          setState(() => _currentStep++);
                        } else {
                          _finishAssessment();
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        _currentStep == 3 ? 'Generate Personalized Analysis 🚀' : 'Next Step →',
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepPill(int step, String label) {
    final isActive = _currentStep == step;
    final isDone = _currentStep > step;
    return Row(
      children: [
        Container(
          width: 24,
          height: 24,
          decoration: BoxDecoration(
            color: isActive
                ? AppColors.accent
                : isDone
                    ? AppColors.success
                    : AppColors.surfaceVariant,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: isDone
                ? const Icon(Icons.check, size: 14, color: Colors.white)
                : Text(
                    '${step + 1}',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: isActive ? Colors.white : AppColors.textSecondary,
                    ),
                  ),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
            color: isActive ? AppColors.accent : AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildStepDivider(int step) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        color: _currentStep > step ? AppColors.success : AppColors.border,
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildAcademicStep();
      case 1:
        return _buildTechnicalStep();
      case 2:
        return _buildInterestsStep();
      case 3:
      default:
        return _buildPreferencesStep();
    }
  }

  Widget _buildAcademicStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Academic Performance & Subjects', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text('Your coursework baseline informs your readiness for advanced tracks.', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        const SizedBox(height: 20),

        // CGPA Slider
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Current Cumulative CGPA', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                  Text('${_profile.cgpa.toStringAsFixed(1)} / 10.0', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.primary)),
                ],
              ),
              Slider(
                value: _profile.cgpa,
                min: 6.0,
                max: 10.0,
                divisions: 40,
                onChanged: (v) => setState(() => _profile.cgpa = double.parse(v.toStringAsFixed(1))),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        _buildTagSelector('Strongest Subjects', ['DBMS', 'Linear Algebra', 'Python Programming', 'Algorithms', 'Discrete Math', 'OS'], _profile.strongestSubjects),
        const SizedBox(height: 16),
        _buildTagSelector('Subjects You Truly Enjoy', ['Artificial Intelligence', 'Linear Algebra', 'Algorithms', 'Computer Vision', 'Web Dev', 'Distributed Systems'], _profile.enjoyedSubjects),
        const SizedBox(height: 16),
        _buildTagSelector('Weakest / High Friction Subjects', ['Computer Networks', 'Physics', 'Digital Electronics', 'Compiler Design', 'Statistics'], _profile.weakestSubjects),
      ],
    );
  }

  Widget _buildTechnicalStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Technical Skills & Self-Ratings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text('Rate your confidence levels honestly (1 to 5 stars).', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        const SizedBox(height: 20),

        _buildTagSelector('Programming Languages Known', ['Python', 'C++', 'Java', 'SQL', 'JavaScript', 'Go', 'Rust'], _profile.languages),
        const SizedBox(height: 16),

        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Column(
            children: [
              _buildRatingRow('Mathematics (Linear Algebra & Calculus)', _profile.mathComfort, (v) => setState(() => _profile.mathComfort = v)),
              const Divider(height: 16),
              _buildRatingRow('Statistics & Probability', _profile.statsComfort, (v) => setState(() => _profile.statsComfort = v)),
              const Divider(height: 16),
              _buildRatingRow('Data Structures & Algorithms (DSA)', _profile.dsaKnowledge, (v) => setState(() => _profile.dsaKnowledge = v)),
              const Divider(height: 16),
              _buildRatingRow('Databases & SQL', _profile.databaseKnowledge, (v) => setState(() => _profile.databaseKnowledge = v)),
              const Divider(height: 16),
              _buildRatingRow('Operating Systems & Low-Level', _profile.systemsKnowledge, (v) => setState(() => _profile.systemsKnowledge = v)),
              const Divider(height: 16),
              _buildRatingRow('Computer Networks & Security', _profile.networkingKnowledge, (v) => setState(() => _profile.networkingKnowledge = v)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInterestsStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Interests & Career Vision', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text('What kind of problems excite you to solve in industry?', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        const SizedBox(height: 20),

        _buildTagSelector('Core Focus Areas', ['AI / ML', 'Data Science', 'Software Engineering', 'Cybersecurity', 'Cloud & DevOps', 'Web Systems', 'Research / R&D'], _profile.interests),
        const SizedBox(height: 16),

        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Target Job Role', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _profile.desiredRole,
                decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                items: [
                  'Machine Learning Engineer',
                  'Data Scientist',
                  'Software Development Engineer (SDE)',
                  'Security Operations / Pen Tester',
                  'Cloud Solutions Architect',
                ].map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
                onChanged: (v) => setState(() => _profile.desiredRole = v ?? 'Machine Learning Engineer'),
              ),
              const SizedBox(height: 16),

              const Text('Target Company Type', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _profile.companyType,
                decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                items: ['Product', 'Startup', 'Research Lab', 'Service', 'Higher Studies'].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setState(() => _profile.companyType = v ?? 'Product'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPreferencesStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Personal Decision Priorities', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        const Text('What matters most in your specialization choice? (1 = Low, 5 = Critical)', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        const SizedBox(height: 20),

        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
          child: Column(
            children: [
              _buildWeightSlider('Intellectual Interest & Passion', _profile.priorityInterest, (v) => setState(() => _profile.priorityInterest = v)),
              const Divider(height: 16),
              _buildWeightSlider('Salary & Compensation Potential', _profile.prioritySalary, (v) => setState(() => _profile.prioritySalary = v)),
              const Divider(height: 16),
              _buildWeightSlider('Career Pathway Flexibility', _profile.priorityFlexibility, (v) => setState(() => _profile.priorityFlexibility = v)),
              const Divider(height: 16),
              _buildWeightSlider('Research & Academic Publishing', _profile.priorityResearch, (v) => setState(() => _profile.priorityResearch = v)),
              const Divider(height: 16),
              _buildWeightSlider('International Relocation Opportunities', _profile.priorityInternational, (v) => setState(() => _profile.priorityInternational = v)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildRatingRow(String label, int currentVal, ValueChanged<int> onChanged) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(child: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(5, (index) {
            final star = index + 1;
            return GestureDetector(
              onTap: () => onChanged(star),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2.0),
                child: Icon(
                  star <= currentVal ? Icons.star : Icons.star_border,
                  size: 22,
                  color: star <= currentVal ? Colors.amber : AppColors.border,
                ),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildWeightSlider(String label, int value, ValueChanged<int> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            Text('$value / 5', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.accent)),
          ],
        ),
        Slider(
          value: value.toDouble(),
          min: 1,
          max: 5,
          divisions: 4,
          activeColor: AppColors.accent,
          onChanged: (v) => onChanged(v.round()),
        ),
      ],
    );
  }

  Widget _buildTagSelector(String title, List<String> available, List<String> selected) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: available.map((tag) {
              final isChosen = selected.contains(tag);
              return FilterChip(
                label: Text(tag),
                selected: isChosen,
                selectedColor: AppColors.accentLight.withOpacity(0.5),
                checkmarkColor: AppColors.accent,
                labelStyle: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isChosen ? AppColors.accent : AppColors.textSecondary,
                ),
                onSelected: (val) {
                  setState(() {
                    if (val) {
                      selected.add(tag);
                    } else {
                      selected.remove(tag);
                    }
                  });
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
