import '../models/specialization_model.dart';
import '../data/specialization_data.dart';

class SpecializationEngine {
  /// Evaluates student's profile across 6 core criteria, applies user preference weighting,
  /// and returns ranked specializations with primary match, alternatives, and what-if rationale.
  static List<SpecializationOption> evaluateSpecializations({
    required SpecializationProfile profile,
    String? previousPrimaryTitle,
  }) {
    final catalog = SpecializationCatalog.defaultOptions;
    final evaluated = <SpecializationOption>[];

    for (final option in catalog) {
      double interestFit = 0.50;
      double skillFit = 0.50;
      double academicFit = 0.50;
      double careerFit = 0.50;
      double marketAlignment = 0.85;

      final isAimL = option.id.contains('aiml');
      final isData = option.id.contains('data');
      final isCyber = option.id.contains('cyber');
      final isSwe = option.id.contains('software');

      // 1. Interest Fit
      if (isAimL) {
        final matches = profile.interests.where((i) => i.contains('AI') || i.contains('Machine Learning')).length;
        interestFit = matches > 0 ? 0.94 : 0.60;
      } else if (isData) {
        final matches = profile.interests.where((i) => i.contains('Data')).length;
        interestFit = matches > 0 ? 0.86 : 0.65;
      } else if (isCyber) {
        final matches = profile.interests.where((i) => i.contains('Security') || i.contains('Cyber')).length;
        interestFit = matches > 0 ? 0.85 : 0.55;
      } else if (isSwe) {
        final matches = profile.interests.where((i) => i.contains('Software')).length;
        interestFit = matches > 0 ? 0.88 : 0.70;
      }

      // 2. Skill Fit
      if (isAimL) {
        double mathFactor = (profile.mathComfort + profile.statsComfort) / 10.0;
        double codeFactor = profile.languages.contains('Python') ? 0.95 : 0.60;
        skillFit = (mathFactor * 0.5) + (codeFactor * 0.5);
      } else if (isData) {
        double dbFactor = (profile.databaseKnowledge + profile.statsComfort) / 10.0;
        double sqlFactor = profile.languages.contains('SQL') ? 0.90 : 0.60;
        skillFit = (dbFactor * 0.6) + (sqlFactor * 0.4);
      } else if (isCyber) {
        double netFactor = (profile.networkingKnowledge + profile.systemsKnowledge) / 10.0;
        skillFit = netFactor.clamp(0.40, 0.95);
      } else if (isSwe) {
        double dsaFactor = (profile.dsaKnowledge + profile.systemsKnowledge) / 10.0;
        double oopFactor = profile.languages.contains('C++') || profile.languages.contains('Java') ? 0.90 : 0.60;
        skillFit = (dsaFactor * 0.6) + (oopFactor * 0.4);
      }

      // 3. Academic Fit (strongest subjects & CGPA)
      if (profile.cgpa >= 8.5) {
        academicFit = 0.90;
      } else if (profile.cgpa >= 7.5) {
        academicFit = 0.80;
      } else {
        academicFit = 0.70;
      }

      // 4. Career Fit
      if (isAimL && (profile.desiredRole.contains('Machine Learning') || profile.desiredRole.contains('AI'))) {
        careerFit = 0.96;
      } else if (isSwe && (profile.desiredRole.contains('Software') || profile.desiredRole.contains('SDE') || profile.desiredRole.contains('Backend'))) {
        careerFit = 0.95;
      } else if (isData && (profile.desiredRole.contains('Data') || profile.desiredRole.contains('Analyst'))) {
        careerFit = 0.92;
      } else if (isCyber && (profile.desiredRole.contains('Security') || profile.desiredRole.contains('SOC'))) {
        careerFit = 0.92;
      }

      // User preference weights (1 to 5 scale normalized)
      double wInterest = profile.priorityInterest / 5.0;
      double wSalary = profile.prioritySalary / 5.0;
      double wFlexibility = profile.priorityFlexibility / 5.0;
      double wResearch = profile.priorityResearch / 5.0;

      // Adjust scores based on specific preferences:
      // If user heavily values Flexibility, Software Engineering & Data Science gain advantage
      if (profile.priorityFlexibility >= 4) {
        if (isSwe) marketAlignment = 0.98;
        if (isData) marketAlignment = 0.92;
      }

      // If user heavily values Research, AI/ML gets boost
      if (profile.priorityResearch >= 4 && isAimL) {
        interestFit = (interestFit + 0.1).clamp(0.0, 1.0);
      }

      // Calculate composite score
      double composite = (interestFit * 0.30 * wInterest) +
          (skillFit * 0.25) +
          (academicFit * 0.15) +
          (careerFit * 0.20 * wSalary) +
          (marketAlignment * 0.10 * wFlexibility);

      // Normalize to percentage (0 - 100)
      int matchPct = (composite * 105).round().clamp(55, 96);

      evaluated.add(
        SpecializationOption(
          id: option.id,
          title: option.title,
          alignmentLevel: option.alignmentLevel, // will be reclassified below
          matchPercentage: matchPct,
          summaryExplanation: option.summaryExplanation,
          factors: {
            'Interest Fit': interestFit,
            'Skill Fit': skillFit,
            'Academic Fit': academicFit,
            'Career Fit': careerFit,
            'Market Alignment': marketAlignment,
          },
          skillGaps: option.skillGaps,
          marketRoles: option.marketRoles,
          commonSkills: option.commonSkills,
          programmingLanguages: option.programmingLanguages,
          technologies: option.technologies,
          typicalProjectTypes: option.typicalProjectTypes,
          entryLevelExpectations: option.entryLevelExpectations,
          roadmap: option.roadmap,
        ),
      );
    }

    // Sort descending by match percentage
    evaluated.sort((a, b) => b.matchPercentage.compareTo(a.matchPercentage));

    // Reclassify top as "Strong Alignment", runner-ups as "Also Consider", lowest as "Different Path"
    final reclassified = <SpecializationOption>[];
    for (int i = 0; i < evaluated.length; i++) {
      final item = evaluated[i];
      String level;
      if (i == 0) {
        level = 'Strong Alignment';
      } else if (i == 1 || i == 2) {
        level = 'Also Consider';
      } else {
        level = 'Different Path';
      }

      reclassified.add(
        SpecializationOption(
          id: item.id,
          title: item.title,
          alignmentLevel: level,
          matchPercentage: item.matchPercentage,
          summaryExplanation: item.summaryExplanation,
          factors: item.factors,
          skillGaps: item.skillGaps,
          marketRoles: item.marketRoles,
          commonSkills: item.commonSkills,
          programmingLanguages: item.programmingLanguages,
          technologies: item.technologies,
          typicalProjectTypes: item.typicalProjectTypes,
          entryLevelExpectations: item.entryLevelExpectations,
          roadmap: item.roadmap,
        ),
      );
    }

    return reclassified;
  }
}
