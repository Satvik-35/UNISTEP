import '../lib/engines/daily_decision_engine.dart';
import '../lib/engines/specialization_engine.dart';
import '../lib/data/demo_data.dart';
import '../lib/models/specialization_model.dart';

void main() {
  print('=== UNI STEP DECISION ENGINE TEST SUITE ===');

  // Test 1: Rahul baseline recommendation (90 min available)
  final profile = DemoData.rahulProfile;
  final tasks = DemoData.initialTasks;

  final decision90 = DailyDecisionEngine.evaluateNextAction(
    tasks: tasks,
    profile: profile,
    overrideAvailableMinutes: 90,
  );

  print('Test 1 (90m available): Recommended -> ${decision90.recommendedTask.title}');
  if (!decision90.recommendedTask.title.contains('DBMS Assignment')) {
    throw Exception('Test 1 failed: Expected DBMS Assignment');
  }
  if (decision90.totalScore < 70) {
    throw Exception('Test 1 failed: Score too low');
  }
  print('✓ Test 1 Passed: Recommended "${decision90.recommendedTask.title}" with score ${decision90.totalScore.round()}%');

  // Test 2: What-If simulation with restricted time (45 minutes)
  final decision45 = DailyDecisionEngine.evaluateNextAction(
    tasks: tasks,
    profile: profile,
    overrideAvailableMinutes: 45,
    previousRecommendationTitle: 'Complete DBMS Assignment',
  );

  print('Test 2 (45m available): Recommended -> ${decision45.recommendedTask.title}');
  if (decision45.recommendedTask.durationMinutes > 45) {
    throw Exception('Test 2 failed: Hard constraint violation: duration > 45');
  }
  print('✓ Test 2 Passed: Shifted to "${decision45.recommendedTask.title}" (${decision45.recommendedTask.durationMinutes}m). Reason: ${decision45.changeReason}');

  // Test 3: Specialization Engine baseline evaluation
  final specProfile = SpecializationProfile();
  final specResults = SpecializationEngine.evaluateSpecializations(profile: specProfile);

  print('Test 3 (Specialization): Top match -> ${specResults.first.title}');
  if (specResults.first.alignmentLevel != 'Strong Alignment') {
    throw Exception('Test 3 failed: Top track must be Strong Alignment');
  }
  if (!specResults.first.title.contains('AI / Machine Learning')) {
    throw Exception('Test 3 failed: Expected AI/ML');
  }
  print('✓ Test 3 Passed: AI/ML scored ${specResults.first.matchPercentage}% with ${specResults.first.roadmap.length}-stage roadmap');

  // Test 4: Specialization What-If (High Flexibility)
  final flexProfile = SpecializationProfile(priorityFlexibility: 5, priorityResearch: 1);
  final flexResults = SpecializationEngine.evaluateSpecializations(profile: flexProfile);
  print('Test 4 (High Flexibility): Top match -> ${flexResults.first.title}');
  print('✓ Test 4 Passed: Specialization recalculated smoothly');

  print('\n=== ALL 4 ENGINE & CONSTRAINT TESTS PASSED VERIFIED! ===');
}
