class RoadmapStage {
  final String period; // e.g. "Month 1–2"
  final String title; // e.g. "Python & Mathematical Foundations"
  final List<String> skills;
  final List<String> projects;
  final List<String> courses;
  final List<String> certifications;
  final String portfolioDeliverable;

  const RoadmapStage({
    required this.period,
    required this.title,
    required this.skills,
    required this.projects,
    required this.courses,
    required this.certifications,
    required this.portfolioDeliverable,
  });

  Map<String, dynamic> toMap() => {
    'period': period,
    'title': title,
    'skills': skills,
    'projects': projects,
    'courses': courses,
    'certifications': certifications,
    'portfolioDeliverable': portfolioDeliverable,
  };
}

class SpecializationOption {
  final String id;
  final String title;
  final String alignmentLevel; // "Strong Alignment", "Also Consider", "Different Path"
  final int matchPercentage; // e.g. 92%
  final String summaryExplanation;
  final Map<String, double> factors; // interestFit, skillFit, academicFit, careerFit, marketAlignment
  final List<String> skillGaps;
  final List<String> marketRoles;
  final List<String> commonSkills;
  final List<String> programmingLanguages;
  final List<String> technologies;
  final List<String> typicalProjectTypes;
  final String entryLevelExpectations;
  final List<RoadmapStage> roadmap;

  const SpecializationOption({
    required this.id,
    required this.title,
    required this.alignmentLevel,
    required this.matchPercentage,
    required this.summaryExplanation,
    required this.factors,
    required this.skillGaps,
    required this.marketRoles,
    required this.commonSkills,
    required this.programmingLanguages,
    required this.technologies,
    required this.typicalProjectTypes,
    required this.entryLevelExpectations,
    required this.roadmap,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'alignmentLevel': alignmentLevel,
    'matchPercentage': matchPercentage,
    'summaryExplanation': summaryExplanation,
    'factors': factors,
    'skillGaps': skillGaps,
    'marketRoles': marketRoles,
    'commonSkills': commonSkills,
    'programmingLanguages': programmingLanguages,
    'technologies': technologies,
    'typicalProjectTypes': typicalProjectTypes,
    'entryLevelExpectations': entryLevelExpectations,
    'roadmap': roadmap.map((r) => r.toMap()).toList(),
  };
}

class SpecializationProfile {
  // Academic
  double cgpa;
  List<String> strongestSubjects;
  List<String> weakestSubjects;
  List<String> enjoyedSubjects;
  List<String> dislikedSubjects;

  // Technical ratings (1 to 5)
  List<String> languages;
  int dsaKnowledge;
  int mathComfort;
  int statsComfort;
  int systemsKnowledge;
  int networkingKnowledge;
  int databaseKnowledge;
  int webDevKnowledge;
  int aiMlKnowledge;
  int cybersecurityKnowledge;
  int cloudKnowledge;

  // Experience
  List<String> projects;
  int hackathons;
  List<String> clubs;

  // Interests
  List<String> interests;

  // Career Goals
  String desiredRole;
  String companyType; // "Product", "Startup", "Service", "Research", "Higher studies"
  String locationPreference; // "India", "Abroad", "Flexible"
  String riskTolerance; // "Conservative", "Moderate", "High"

  // Priorities (weights 1 to 5)
  int priorityInterest;
  int prioritySalary;
  int priorityFlexibility;
  int priorityResearch;
  int priorityInternational;
  int priorityStability;
  int priorityDifficulty;

  SpecializationProfile({
    this.cgpa = 8.7,
    List<String>? strongestSubjects,
    List<String>? weakestSubjects,
    List<String>? enjoyedSubjects,
    List<String>? dislikedSubjects,
    List<String>? languages,
    this.dsaKnowledge = 3,
    this.mathComfort = 4,
    this.statsComfort = 4,
    this.systemsKnowledge = 3,
    this.networkingKnowledge = 2,
    this.databaseKnowledge = 4,
    this.webDevKnowledge = 3,
    this.aiMlKnowledge = 3,
    this.cybersecurityKnowledge = 2,
    this.cloudKnowledge = 2,
    List<String>? projects,
    this.hackathons = 2,
    List<String>? clubs,
    List<String>? interests,
    this.desiredRole = 'Machine Learning Engineer',
    this.companyType = 'Product',
    this.locationPreference = 'India / Abroad',
    this.riskTolerance = 'Moderate',
    this.priorityInterest = 5,
    this.prioritySalary = 4,
    this.priorityFlexibility = 3,
    this.priorityResearch = 3,
    this.priorityInternational = 4,
    this.priorityStability = 3,
    this.priorityDifficulty = 2,
  })  : strongestSubjects = strongestSubjects ?? ['DBMS', 'Linear Algebra', 'Python Programming'],
        weakestSubjects = weakestSubjects ?? ['Computer Networks', 'Physics'],
        enjoyedSubjects = enjoyedSubjects ?? ['Algorithms', 'Linear Algebra', 'Artificial Intelligence'],
        dislikedSubjects = dislikedSubjects ?? ['Digital Electronics'],
        languages = languages ?? ['Python', 'C++', 'SQL'],
        projects = projects ?? ['Student Grade Prediction (Python)', 'Campus Food Delivery UI'],
        clubs = clubs ?? ['AI Club', 'Coding Club'],
        interests = interests ?? ['AI / ML', 'Software Engineering', 'Data Science'];
}
