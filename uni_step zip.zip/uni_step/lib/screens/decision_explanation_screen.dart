import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../models/decision_item.dart';
import '../widgets/factor_bar.dart';
import '../app/app_state.dart';
import 'what_if_screen.dart';

class DecisionExplanationScreen extends StatelessWidget {
  final AppState appState;
  final DecisionItem decision;

  const DecisionExplanationScreen({
    super.key,
    required this.appState,
    required this.decision,
  });

  @override
  Widget build(BuildContext context) {
    final task = decision.recommendedTask;

    return Scaffold(
      appBar: AppBar(
        title: const Text('DECISION EXPLANATION'),
        actions: [
          IconButton(
            icon: const Icon(Icons.alt_route),
            tooltip: 'What-If Simulation',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => WhatIfScreen(appState: appState)),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Selected Action Card Header
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 3)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.primaryContainer,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.check_circle_outline, color: AppColors.primary, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              task.title,
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                            ),
                            Text(
                              '${task.durationMinutes} mins • ${task.locationName}',
                              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceVariant,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'AI Decision Engine evaluated 5 academic and spatial constraints to eliminate ambiguity and choose this single highest-yield step.',
                      style: const TextStyle(fontSize: 12, height: 1.4, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // WHY UNI STEP RECOMMENDED THIS - Visual Factor Bars
            const Text(
              'WHY UNI STEP RECOMMENDED THIS',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: decision.factors.map((f) {
                  return FactorBar(
                    label: f.label,
                    score: f.score,
                    subtitle: f.description,
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            // WHAT YOU GAIN vs WHAT YOU GIVE UP
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Gain Box
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.successContainer.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.success.withOpacity(0.3)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.add_circle, color: AppColors.success, size: 16),
                            SizedBox(width: 6),
                            Text(
                              'WHAT YOU GAIN',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF065F46),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        ...decision.gains.map(
                          (g) => Padding(
                            padding: const EdgeInsets.only(bottom: 6.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('✓ ', style: TextStyle(color: AppColors.success, fontWeight: FontWeight.bold)),
                                Expanded(
                                  child: Text(g, style: const TextStyle(fontSize: 12, height: 1.3, color: AppColors.textPrimary)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Give Up Box
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.warningContainer.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.warning.withOpacity(0.3)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.remove_circle, color: AppColors.warning, size: 16),
                            SizedBox(width: 6),
                            Text(
                              'WHAT YOU GIVE UP',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF92400E),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        ...decision.giveUps.map(
                          (gu) => Padding(
                            padding: const EdgeInsets.only(bottom: 6.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('— ', style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.bold)),
                                Expanded(
                                  child: Text(gu, style: const TextStyle(fontSize: 12, height: 1.3, color: AppColors.textPrimary)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Button: Start Step & Mark in Progress
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    backgroundColor: AppColors.success,
                    content: Text('Started: ${task.title} (Timer initiated)'),
                  ),
                );
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary,
                minimumSize: const Size(double.infinity, 54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Start This Action Now', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => WhatIfScreen(appState: appState)),
                );
              },
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Explore What-If Scenarios', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}
