import '../models/campus_location.dart';
import '../data/demo_data.dart';

abstract class MapsService {
  Future<List<CampusLocation>> getLocations();
  Future<int> getTravelTimeMinutes(String fromLocationId, String toLocationId);
  CampusLocation? getLocationById(String id);
  bool get isGoogleMapsLive;
}

class MockCampusMapsService implements MapsService {
  final List<CampusLocation> _locations = List.from(DemoData.campusLocations);

  @override
  bool get isGoogleMapsLive => false; // Fallback to interactive SVG/Vector campus map

  @override
  Future<List<CampusLocation>> getLocations() async {
    return _locations;
  }

  @override
  Future<int> getTravelTimeMinutes(String fromLocationId, String toLocationId) async {
    final toLoc = getLocationById(toLocationId);
    return toLoc?.travelTimeMinutes ?? 5;
  }

  @override
  CampusLocation? getLocationById(String id) {
    try {
      return _locations.firstWhere((l) => l.id == id || l.name.toLowerCase() == id.toLowerCase());
    } catch (_) {
      return null;
    }
  }
}
