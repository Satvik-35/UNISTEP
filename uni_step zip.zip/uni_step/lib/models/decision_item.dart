import 'task_item.dart';

class DecisionFactor {
  final String label;
  final double score; // 0.0 to 1.0 (e.g. 0.90 for 90%)
  final String description;

  const DecisionFactor({
    required this.label,
    required this.score,
    required this.description,
  });

  Map<String, dynamic> toMap() => {
    'label': label,
    'score': score,
    'description': description,
  };
}

class DecisionItem {
  final String id;
  final TaskItem recommendedTask;
  final double totalScore; // 0 to 100
  final List<DecisionFactor> factors;
  final List<String> reasons;
  final String tradeOff;
  final List<String> gains;
  final List<String> giveUps;
  final List<TaskItem> alternatives;
  final DateTime timestamp;
  final String contextSummary; // e.g. "90 mins free • Library • High Academic Priority"
  final String changeReason; // used for What-If scenario changes

  const DecisionItem({
    required this.id,
    required this.recommendedTask,
    required this.totalScore,
    required this.factors,
    required this.reasons,
    required this.tradeOff,
    required this.gains,
    required this.giveUps,
    required this.alternatives,
    required this.timestamp,
    required this.contextSummary,
    this.changeReason = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'recommendedTask': recommendedTask.toMap(),
      'totalScore': totalScore,
      'factors': factors.map((f) => f.toMap()).toList(),
      'reasons': reasons,
      'tradeOff': tradeOff,
      'gains': gains,
      'giveUps': giveUps,
      'alternatives': alternatives.map((a) => a.toMap()).toList(),
      'timestamp': timestamp.toIso8601String(),
      'contextSummary': contextSummary,
      'changeReason': changeReason,
    };
  }
}
