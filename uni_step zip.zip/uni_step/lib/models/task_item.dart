enum TaskType { assignment, examPrep, clubEvent, lecture, project, revision }

class TaskItem {
  final String id;
  final String title;
  final TaskType type;
  final int durationMinutes;
  final String dueText;
  final double deadlineHoursLeft; // e.g. 5.0 for tonight, 72.0 for 3 days
  final int academicImpact; // 0 to 100
  final int examProximityDays; // e.g. 3 days until DBMS exam
  final String locationName;
  final int travelTimeMinutes;
  final int completionPercent; // e.g. 60% complete
  final String details;
  final String courseCode;

  const TaskItem({
    required this.id,
    required this.title,
    required this.type,
    required this.durationMinutes,
    required this.dueText,
    required this.deadlineHoursLeft,
    required this.academicImpact,
    required this.examProximityDays,
    required this.locationName,
    required this.travelTimeMinutes,
    required this.completionPercent,
    required this.details,
    required this.courseCode,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'type': type.name,
      'durationMinutes': durationMinutes,
      'dueText': dueText,
      'deadlineHoursLeft': deadlineHoursLeft,
      'academicImpact': academicImpact,
      'examProximityDays': examProximityDays,
      'locationName': locationName,
      'travelTimeMinutes': travelTimeMinutes,
      'completionPercent': completionPercent,
      'details': details,
      'courseCode': courseCode,
    };
  }

  factory TaskItem.fromMap(Map<String, dynamic> map) {
    return TaskItem(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      type: TaskType.values.firstWhere(
        (e) => e.name == map['type'],
        orElse: () => TaskType.assignment,
      ),
      durationMinutes: map['durationMinutes']?.toInt() ?? 60,
      dueText: map['dueText'] ?? '',
      deadlineHoursLeft: (map['deadlineHoursLeft'] as num?)?.toDouble() ?? 24.0,
      academicImpact: map['academicImpact']?.toInt() ?? 50,
      examProximityDays: map['examProximityDays']?.toInt() ?? 7,
      locationName: map['locationName'] ?? 'Campus',
      travelTimeMinutes: map['travelTimeMinutes']?.toInt() ?? 5,
      completionPercent: map['completionPercent']?.toInt() ?? 0,
      details: map['details'] ?? '',
      courseCode: map['courseCode'] ?? '',
    );
  }
}
