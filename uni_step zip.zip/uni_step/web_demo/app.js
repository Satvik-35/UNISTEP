// ═══════════════════════════════════════════════════
// UNI STEP — Complete Interactive Application (v2.0)
// Make better decisions. Move forward.
// ═══════════════════════════════════════════════════

let currentScreen = 'welcome';
let previousScreen = 'welcome';
let activeMinutes = 90;
let activeLocation = 'Academic Block 3';
let activePriority = 'High';
let currentDecision = null;
let currentSpecializationResult = null;
let whatIfTimeoutId = null;

// ─── INIT ───────────────────────────────────────────────────────────────────
function init() {
  currentDecision = DecisionEngine.evaluateNextAction(activeMinutes, activeLocation, activePriority);
  currentSpecializationResult = DecisionEngine.evaluateSpecialization(AppData.specializationProfile);

  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.getAttribute('data-tab');
      navigateToTab(tabName);
    });
  });

  renderScreen('welcome');
}

// ─── NAVIGATION ─────────────────────────────────────────────────────────────
function navigateToTab(tabName) {
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  const activeBtn = document.getElementById(`tab-${tabName}`);
  if (activeBtn) activeBtn.classList.add('active');

  const screenMap = {
    home: 'home',
    decide: 'decide',
    specialization: 'specialization_result',
    map: 'map',
    profile: 'profile',
  };
  renderScreen(screenMap[tabName] || 'home');
}

function showBottomNav(show) {
  const nav = document.getElementById('bottom-nav');
  if (nav) nav.style.display = show ? 'flex' : 'none';
}

function syncNavTab(screenName) {
  const tabMap = {
    home: 'home',
    decide: 'decide',
    what_if: 'decide',
    explanation: 'home',
    specialization_result: 'specialization',
    specialization_what_if: 'specialization',
    roadmap: 'specialization',
    specialization_assessment: 'specialization',
    map: 'map',
    profile: 'profile',
    settings: 'profile',
  };
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  const tabId = tabMap[screenName];
  if (tabId) {
    const el = document.getElementById(`tab-${tabId}`);
    if (el) el.classList.add('active');
  }
}

// ─── RENDER SCREEN ──────────────────────────────────────────────────────────
function renderScreen(screenName, params = {}) {
  previousScreen = currentScreen;
  currentScreen = screenName;

  const root = document.getElementById('app-root');
  root.innerHTML = '';
  root.scrollTop = 0;

  const mainScreens = ['home', 'decide', 'specialization_result', 'map', 'profile'];
  showBottomNav(mainScreens.includes(screenName));
  syncNavTab(screenName);

  const screenRenderers = {
    welcome: () => renderWelcomeScreen(),
    login: () => renderLoginScreen(),
    create_account: () => renderCreateAccountScreen(),
    home: () => renderHomeScreen(),
    decide: () => renderDecideScreen(),
    explanation: () => renderExplanationScreen(),
    what_if: () => renderWhatIfScreen(),
    specialization_assessment: () => renderAssessmentScreen(params.step || 0),
    specialization_result: () => renderSpecializationResultScreen(),
    specialization_what_if: () => renderSpecializationWhatIfScreen(),
    roadmap: () => renderRoadmapScreen(),
    map: () => renderCampusMapScreen(),
    history: () => renderHistoryScreen(),
    profile: () => renderProfileScreen(),
    settings: () => renderSettingsScreen(),
    terms: () => renderTermsScreen(),
    privacy: () => renderPrivacyScreen(),
  };

  const renderer = screenRenderers[screenName];
  if (renderer) {
    const wrapper = document.createElement('div');
    wrapper.className = 'screen-animate';
    wrapper.innerHTML = renderer();
    root.appendChild(wrapper);
  }

  // Setup listeners AFTER DOM is ready
  if (screenName === 'what_if') setupWhatIfListeners();
  if (screenName === 'specialization_what_if') setupSpecializationWhatIfListeners();
  if (screenName === 'map') setupMapListeners();
}

// ═══════════════════════════════════════════════════
// SCREEN RENDERERS
// ═══════════════════════════════════════════════════

// ─── 1. WELCOME SCREEN ──────────────────────────────────────────────────────
function renderWelcomeScreen() {
  return `
    <div style="padding: 28px 24px; min-height: 100%; display: flex; flex-direction: column; justify-content: space-between; background: var(--bg);">
      <!-- Logo Hero -->
      <div style="text-align: center; margin-top: 24px;">
        <div class="hero-icon" style="width: 80px; height: 80px; margin: 0 auto 20px; border-radius: 24px; background: linear-gradient(135deg, #2563EB, #1D4ED8); display: flex; align-items: center; justify-content: center; box-shadow: 0 14px 32px rgba(37,99,235,0.4);">
          <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
            <polyline points="17 6 23 6 23 12"></polyline>
          </svg>
        </div>
        <h1 style="font-size: 34px; font-weight: 900; letter-spacing: -1px; color: var(--text-primary); margin-bottom: 8px;">UNI STEP</h1>
        <div style="display: inline-flex; align-items: center; gap: 6px; background: var(--primary-container); padding: 5px 14px; border-radius: 999px; margin-bottom: 20px;">
          <span style="font-size: 13px; font-weight: 700; color: var(--on-primary-container);">Make better decisions. Move forward.</span>
        </div>
        <p style="font-size: 14px; line-height: 1.6; color: var(--text-secondary); max-width: 300px; margin: 0 auto;">
          Your university signals are scattered. UNI STEP turns them into <strong style="color: var(--text-primary);">one personalized next step.</strong>
        </p>
      </div>

      <!-- Signals Card -->
      <div style="background: white; border-radius: 20px; border: 1px solid var(--border); padding: 16px; margin: 20px 0; box-shadow: var(--shadow-sm);">
        <div style="font-size: 10px; font-weight: 800; color: var(--text-muted); letter-spacing: 1px; margin-bottom: 12px;">CONNECTING YOUR SCATTERED SIGNALS</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
          ${[
            ['📅', 'Timetable & Attendance'],
            ['📝', 'Assignments & Deadlines'],
            ['🧠', 'Exam Countdown (3-day)'],
            ['🗺️', 'Campus Walking Times'],
            ['🎯', 'Specialization Tracks'],
            ['💼', 'Career Alignment'],
          ].map(([icon, label]) => `
            <div style="display: flex; align-items: center; gap: 7px; font-size: 12px; font-weight: 600; color: var(--text-secondary); padding: 6px 0;">
              <span style="font-size: 15px;">${icon}</span> ${label}
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Action Buttons -->
      <div>
        <button class="btn-primary pulse-cta" id="btn-try-demo" onclick="renderScreen('home')" style="margin-bottom: 10px; font-size: 16px;">
          ⚡ Try Demo Mode — Instant Access
        </button>
        <button class="btn-secondary" id="btn-login" onclick="renderScreen('login')" style="margin-bottom: 8px;">Login to My Account</button>
        <button class="btn-secondary" id="btn-create-account" onclick="renderScreen('create_account')" style="margin-bottom: 16px;">Create New Account</button>
        <div style="text-align: center; font-size: 11px; color: var(--text-muted); line-height: 1.5;">
          By continuing, you agree to our 
          <a href="#" onclick="renderScreen('terms'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Terms</a> &amp; 
          <a href="#" onclick="renderScreen('privacy'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Privacy Policy</a>.
          <br><span style="color: var(--text-muted);">This is a hackathon MVP — all data is simulated.</span>
        </div>
      </div>
    </div>
  `;
}

// ─── 2. LOGIN SCREEN ────────────────────────────────────────────────────────
function renderLoginScreen() {
  return `
    <div style="padding: 20px 24px; min-height: 100%;">
      <button class="icon-btn" onclick="renderScreen('welcome')" style="margin-bottom: 16px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <h2 style="font-size: 26px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px; letter-spacing: -0.5px;">Welcome Back 👋</h2>
      <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 20px;">Log in to your personalized decision dashboard</p>

      <div style="background: var(--primary-container); border: 1px solid var(--primary-light); border-radius: 14px; padding: 12px 14px; margin-bottom: 20px;">
        <div style="font-size: 12px; font-weight: 700; color: var(--on-primary-container);">💡 Demo Credentials Pre-filled</div>
        <div style="font-size: 11px; color: var(--text-secondary); margin-top: 3px;">Username: <strong>demo</strong> &nbsp;•&nbsp; Password: <strong>demo123</strong></div>
      </div>

      <div class="input-group">
        <label class="input-label">Username or University Email</label>
        <input type="text" id="login-username" class="input-field" value="demo" placeholder="demo or rahul@srm.edu.in">
      </div>
      <div class="input-group">
        <label class="input-label">Password</label>
        <input type="password" id="login-password" class="input-field" value="demo123" placeholder="••••••••">
      </div>
      <div style="text-align: right; margin-bottom: 18px;">
        <a href="#" onclick="alert('Demo Mode: Use demo / demo123'); return false;" style="font-size: 12px; color: var(--primary); font-weight: 600; text-decoration: none;">Forgot Password?</a>
      </div>

      <button class="btn-primary" id="btn-submit-login" onclick="renderScreen('home')" style="margin-bottom: 10px;">Login →</button>
      <button class="btn-secondary" id="btn-demo-mode" onclick="renderScreen('home')" style="border-color: var(--secondary); color: var(--secondary); font-weight: 700; margin-bottom: 18px;">⚡ Skip to Demo Mode</button>

      <div style="text-align: center; font-size: 13px; color: var(--text-secondary);">
        Don't have an account? <a href="#" onclick="renderScreen('create_account'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Create Account</a>
      </div>
    </div>
  `;
}

// ─── 3. CREATE ACCOUNT SCREEN ───────────────────────────────────────────────
function renderCreateAccountScreen() {
  return `
    <div style="padding: 20px 24px; min-height: 100%;">
      <button class="icon-btn" onclick="renderScreen('welcome')" style="margin-bottom: 16px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <h2 style="font-size: 26px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px; letter-spacing: -0.5px;">Join UNI STEP 🎓</h2>
      <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 20px;">Turn scattered information into a clear next step</p>

      <div class="input-group"><label class="input-label">Full Name</label><input type="text" class="input-field" value="Rahul" placeholder="Your full name"></div>
      <div class="input-group"><label class="input-label">Username</label><input type="text" class="input-field" value="rahul_srm" placeholder="rahul_srm"></div>
      <div class="input-group"><label class="input-label">University Email</label><input type="email" class="input-field" value="rahul@srm.edu.in" placeholder="you@university.edu"></div>
      <div class="input-group"><label class="input-label">University</label><input type="text" class="input-field" value="SRM University AP" placeholder="SRM University AP"></div>
      <div class="input-group">
        <label class="input-label">Academic Year</label>
        <select class="input-field">
          <option>1st Year</option><option selected>2nd Year</option><option>3rd Year</option><option>4th Year</option>
        </select>
      </div>
      <div class="input-group"><label class="input-label">Password</label><input type="password" class="input-field" value="demo123"></div>

      <div style="display: flex; align-items: flex-start; gap: 8px; margin: 16px 0; font-size: 12px; color: var(--text-secondary);">
        <input type="checkbox" checked style="margin-top: 2px; accent-color: var(--primary);">
        <span>I agree to the <a href="#" onclick="renderScreen('terms'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Terms</a> &amp; <a href="#" onclick="renderScreen('privacy'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Privacy Policy</a>.</span>
      </div>
      <button class="btn-primary" onclick="renderScreen('home')" style="margin-bottom: 14px;">Create Account →</button>
      <div style="text-align: center; font-size: 13px; color: var(--text-secondary);">
        Already have an account? <a href="#" onclick="renderScreen('login'); return false;" style="color: var(--primary); font-weight: 700; text-decoration: none;">Login</a>
      </div>
    </div>
  `;
}

// ─── 4. HOME SCREEN ─────────────────────────────────────────────────────────
function renderHomeScreen() {
  const dec = currentDecision;
  const p = AppData.profile;

  return `
    <!-- Sticky Header -->
    <div class="screen-header">
      <div class="brand-badge">
        <div class="brand-icon">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
        </div>
        <span>UNI STEP</span>
      </div>
      <div class="header-actions">
        <button class="icon-btn" onclick="renderScreen('history')" title="Decision Audit Log">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
        </button>
        <button class="icon-btn" onclick="renderScreen('settings')" title="Settings">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
        </button>
      </div>
    </div>

    <div style="padding: 14px 18px 24px;">
      <!-- Greeting -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px;">
        <div>
          <h2 style="font-size: 22px; font-weight: 800; color: var(--text-primary); letter-spacing: -0.5px;">Good morning, ${p.name} 👋</h2>
          <div style="font-size: 12px; color: var(--text-secondary); margin-top: 2px;">${p.university} &bull; ${p.year}</div>
        </div>
        <div class="badge badge-primary" style="flex-shrink: 0;">⏱️ ${activeMinutes}m free</div>
      </div>

      <!-- Live Context Cards (2x2 grid) -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 18px;">
        <div style="background: white; border: 1px solid var(--border); border-radius: 14px; padding: 12px; box-shadow: var(--shadow-sm);">
          <div style="font-size: 10px; font-weight: 700; color: var(--text-muted); letter-spacing: 0.5px;">NEXT CLASS</div>
          <div style="font-size: 13px; font-weight: 700; color: var(--text-primary); margin-top: 3px;">CSE 204 • 2:00 PM</div>
        </div>
        <div style="background: white; border: 1px solid rgba(239,68,68,0.3); border-radius: 14px; padding: 12px; box-shadow: var(--shadow-sm);">
          <div style="font-size: 10px; font-weight: 700; color: var(--text-muted); letter-spacing: 0.5px;">URGENT DEADLINE</div>
          <div style="font-size: 13px; font-weight: 700; color: var(--error); margin-top: 3px;">DBMS (Tonight)</div>
        </div>
        <div style="background: white; border: 1px solid rgba(245,158,11,0.3); border-radius: 14px; padding: 12px; box-shadow: var(--shadow-sm);">
          <div style="font-size: 10px; font-weight: 700; color: var(--text-muted); letter-spacing: 0.5px;">EXAM COUNTDOWN</div>
          <div style="font-size: 13px; font-weight: 700; color: var(--warning); margin-top: 3px;">DBMS Midterm (3d)</div>
        </div>
        <div style="background: white; border: 1px solid rgba(13,148,136,0.3); border-radius: 14px; padding: 12px; box-shadow: var(--shadow-sm);">
          <div style="font-size: 10px; font-weight: 700; color: var(--text-muted); letter-spacing: 0.5px;">LOCATION</div>
          <div style="font-size: 13px; font-weight: 700; color: var(--secondary); margin-top: 3px;">${activeLocation.split(' ').slice(0,2).join(' ')}</div>
        </div>
      </div>

      <!-- WHAT SHOULD I DO NEXT -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: var(--text-muted);">WHAT SHOULD I DO NEXT?</div>
        <a href="#" onclick="renderScreen('decide'); return false;" style="font-size: 12px; font-weight: 700; color: var(--primary); text-decoration: none;">Full Engine →</a>
      </div>

      <!-- Hero Decision Card -->
      <div class="hero-decision-card" style="cursor: pointer;" onclick="renderScreen('explanation')">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="badge badge-white">⚡ YOUR NEXT STEP</span>
            <span class="ai-badge">AI</span>
          </div>
          <div class="badge-score score-anim">${dec.totalScore}% Fit</div>
        </div>
        <h3 style="font-size: 21px; font-weight: 800; line-height: 1.25; margin-bottom: 10px;">${dec.task.title}</h3>
        
        <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 14px;">
          <span class="badge badge-white">⏱️ ${dec.task.durationMinutes} mins</span>
          <span class="badge badge-white">⚠️ ${dec.task.dueText}</span>
          <span class="badge badge-white">📍 ${dec.task.locationName}</span>
        </div>

        <div style="border-top: 1px solid rgba(255,255,255,0.18); padding-top: 12px; margin-bottom: 14px;">
          <div style="font-size: 10px; font-weight: 800; letter-spacing: 0.8px; opacity: 0.75; margin-bottom: 7px;">WHY THIS?</div>
          <div style="font-size: 13px; line-height: 1.5; opacity: 0.95;">
            ${dec.reasons.slice(0,3).map(r => `<div style="margin-bottom: 3px;">• ${r}</div>`).join('')}
          </div>
        </div>

        <button class="btn-white" id="btn-take-step" onclick="event.stopPropagation(); renderScreen('explanation');">
          Take this step →
        </button>
      </div>

      <!-- What-If Teaser -->
      <div class="card" style="display: flex; align-items: center; gap: 12px; padding: 14px;">
        <div style="width: 42px; height: 42px; border-radius: 12px; background: var(--success-container); color: var(--secondary); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20v-6M6 20V10M18 20V4"/></svg>
        </div>
        <div style="flex: 1; min-width: 0;">
          <div style="font-size: 10px; font-weight: 800; color: var(--secondary); letter-spacing: 0.5px;">WHAT-IF SIMULATION</div>
          <div style="font-size: 13px; font-weight: 700; color: var(--text-primary); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">What if I only have 45 minutes?</div>
        </div>
        <button class="btn-action-small" id="btn-explore-whatif" onclick="renderScreen('what_if')">Explore</button>
      </div>

      <!-- Specialization Feature Card -->
      <div class="card" style="background: linear-gradient(135deg, #4C1D95, #6D28D9, #7C3AED); color: white; border: none; padding: 20px;">
        <div class="badge" style="background: rgba(255,255,255,0.18); color: white; margin-bottom: 10px;">🎓 FLAGSHIP FEATURE</div>
        <h4 style="font-size: 18px; font-weight: 800; margin-bottom: 6px; letter-spacing: -0.3px;">PLAN MY SPECIALIZATION</h4>
        <p style="font-size: 12px; opacity: 0.88; line-height: 1.5; margin-bottom: 14px;">Your 3rd-year specialization is approaching. Get AI-powered alignment between your skills, interests and career goals.</p>
        <button class="btn-white" id="btn-start-assessment" style="color: #5B21B6;" onclick="renderScreen('specialization_assessment')">Start Assessment →</button>
      </div>

      <!-- Campus Quick Card -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin: 4px 0 10px;">
        <div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: var(--text-muted);">CAMPUS NAVIGATION</div>
        <a href="#" onclick="renderScreen('map'); return false;" style="font-size: 12px; font-weight: 700; color: var(--primary); text-decoration: none;">Open Map →</a>
      </div>
      <div class="card" style="display: flex; align-items: center; gap: 12px; padding: 14px;">
        <div style="font-size: 24px;">🗺️</div>
        <div style="flex: 1;">
          <div style="font-size: 13px; font-weight: 700;">Central Library &bull; 6 min walk</div>
          <div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">Optimal quiet zone for your next step</div>
        </div>
        <button class="btn-secondary" style="width: auto; padding: 7px 12px; font-size: 12px; border-radius: 10px;" onclick="renderScreen('map')">View</button>
      </div>
    </div>
  `;
}

// ─── 5. DECIDE ENGINE SCREEN ─────────────────────────────────────────────────
function renderDecideScreen() {
  const dec = currentDecision;
  const task = dec.task;

  return `
    <div class="screen-header">
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary); letter-spacing: 0.3px;">WHAT SHOULD I DO NEXT?</div>
      <button class="icon-btn" onclick="renderScreen('what_if')" title="What-If Simulation">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20v-6M6 20V10M18 20V4"/></svg>
      </button>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Context Pill -->
      <div style="background: var(--surface-variant); border-radius: 12px; padding: 10px 14px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 14px;">🔍</span>
        <span style="font-size: 12px; font-weight: 600; color: var(--text-secondary);">${dec.contextSummary}</span>
      </div>

      <!-- Primary Decision Card -->
      <div style="background: white; border-radius: 20px; border: 2px solid rgba(37,99,235,0.25); padding: 20px; margin-bottom: 16px; box-shadow: var(--shadow-md);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="badge badge-primary">⚡ YOUR NEXT STEP</span>
            <span class="ai-badge">AI</span>
          </div>
          <div style="font-size: 13px; font-weight: 800; color: var(--primary);">${dec.totalScore}/100</div>
        </div>

        <h3 style="font-size: 21px; font-weight: 800; color: var(--text-primary); margin-bottom: 6px; letter-spacing: -0.3px;">${task.title}</h3>
        <p style="font-size: 13px; color: var(--text-secondary); line-height: 1.5; margin-bottom: 14px;">${task.details}</p>

        <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px;">
          <span class="badge badge-primary">⏱️ ${task.durationMinutes} mins</span>
          <span class="badge badge-warning">⚠️ ${task.dueText}</span>
          <span class="badge badge-secondary">📍 ${task.locationName}</span>
          <span class="badge badge-primary">✅ ${task.completionPercent}% done</span>
        </div>

        <!-- Why Reasons -->
        <div style="border-top: 1px solid var(--border); padding-top: 14px; margin-bottom: 14px;">
          <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">WHY THIS IS YOUR BEST NEXT STEP</div>
          <div style="display: flex; flex-direction: column; gap: 8px;">
            ${dec.reasons.map((r, i) => `
              <div style="display: flex; gap: 9px; align-items: flex-start;">
                <span style="width: 20px; height: 20px; border-radius: 50%; background: var(--primary-container); color: var(--primary); font-size: 10px; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px;">${i+1}</span>
                <span style="font-size: 13px; color: var(--text-primary); line-height: 1.4;">${r}</span>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Trade-off -->
        <div style="background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3); border-radius: 12px; padding: 12px; margin-bottom: 16px;">
          <div style="font-size: 10px; font-weight: 800; color: #B45309; letter-spacing: 0.5px; margin-bottom: 4px;">⚖️ TRADE-OFF</div>
          <div style="font-size: 12px; line-height: 1.5; color: var(--text-primary);">${dec.tradeOff}</div>
        </div>

        <button class="btn-primary" onclick="renderScreen('explanation')" style="margin-bottom: 8px;">Take This Step →</button>
        <button class="btn-secondary" onclick="renderScreen('what_if')" style="font-size: 13px; padding: 10px;">Simulate Different Scenario</button>
      </div>

      <!-- Alternatives -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">FEASIBLE ALTERNATIVES CONSIDERED</div>
      ${dec.alternatives.length === 0 ? `
        <div style="text-align: center; padding: 20px; color: var(--text-muted); font-size: 13px;">All other tasks are outside your available time window.</div>
      ` : dec.alternatives.map(alt => `
        <div class="card" style="padding: 12px; display: flex; align-items: center; gap: 10px;">
          <div style="font-size: 20px;">📋</div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${alt.title}</div>
            <div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">${alt.durationMinutes}m &bull; ${alt.dueText} &bull; ${alt.locationName}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// ─── 6. DECISION EXPLANATION (WHY THIS DECISION) ────────────────────────────
function renderExplanationScreen() {
  const dec = currentDecision;
  const task = dec.task;

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('home')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">DECISION EXPLANATION</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Task Summary -->
      <div class="card" style="padding: 16px; margin-bottom: 16px;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
          <span class="badge badge-primary">RECOMMENDED ACTION</span>
          <span class="ai-badge">AI Score: ${dec.totalScore}%</span>
        </div>
        <h3 style="font-size: 19px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">${task.title}</h3>
        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 10px;">${task.durationMinutes} mins &bull; ${task.locationName} &bull; ${task.courseCode}</div>
        <div style="font-size: 12px; line-height: 1.5; color: var(--text-muted); background: var(--surface-variant); padding: 10px 12px; border-radius: 10px;">
          Multi-attribute decision engine evaluated ${AppData.tasks.length} tasks across 5 scored factors, eliminating schedule conflicts and prioritizing deadline proximity.
        </div>
      </div>

      <!-- Factor Progress Bars -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">WHY UNI STEP RECOMMENDED THIS</div>
      <div class="card" style="padding: 18px; margin-bottom: 16px;">
        ${dec.factors.map(f => `
          <div class="factor-row">
            <div class="factor-header">
              <span>${f.label}</span>
              <span style="color: var(--primary); font-weight: 800;">${Math.round(f.score * 100)}%</span>
            </div>
            <div class="factor-bar-bg">
              <div class="factor-bar-fill" style="width: ${Math.round(f.score * 100)}%;"></div>
            </div>
            <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">${f.desc}</div>
          </div>
        `).join('')}
      </div>

      <!-- Gain vs Give Up -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 18px;">
        <div style="background: rgba(16,185,129,0.08); border: 1px solid rgba(16,185,129,0.25); border-radius: 16px; padding: 14px;">
          <div style="font-size: 10px; font-weight: 800; color: #065F46; letter-spacing: 0.5px; margin-bottom: 8px;">✅ WHAT YOU GAIN</div>
          <div style="font-size: 12px; color: var(--text-primary); line-height: 1.5;">
            ${dec.gains.map(g => `<div style="margin-bottom: 6px;">${g}</div>`).join('')}
          </div>
        </div>
        <div style="background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.25); border-radius: 16px; padding: 14px;">
          <div style="font-size: 10px; font-weight: 800; color: #92400E; letter-spacing: 0.5px; margin-bottom: 8px;">— WHAT YOU GIVE UP</div>
          <div style="font-size: 12px; color: var(--text-primary); line-height: 1.5;">
            ${dec.giveUps.map(gu => `<div style="margin-bottom: 6px;">${gu}</div>`).join('')}
          </div>
        </div>
      </div>

      <button class="btn-primary" onclick="alert('⏱️ Timer started! Good luck with: ${task.title.replace(/'/g, "\\'")}'); renderScreen('home');" style="margin-bottom: 10px;">Start This Action Now ▶</button>
      <button class="btn-secondary" onclick="renderScreen('what_if')">Explore What-If Scenarios</button>
    </div>
  `;
}

// ─── 7. WHAT-IF SCREEN ──────────────────────────────────────────────────────
function renderWhatIfScreen() {
  const dec = currentDecision;

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('decide')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">WHAT-IF SIMULATION</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Info Banner -->
      <div style="background: linear-gradient(135deg, #047857, #10B981); color: white; border-radius: 18px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 10px; font-weight: 800; letter-spacing: 0.8px; opacity: 0.85; margin-bottom: 4px;">DYNAMIC DECISION SIMULATION</div>
        <div style="font-size: 13px; line-height: 1.5;">Adjust time or location below. The engine recalculates your optimal next step <strong>in real time.</strong></div>
      </div>

      <!-- Controls Card -->
      <div class="card" style="padding: 18px; margin-bottom: 16px;">
        <div class="slider-header">
          <span style="font-size: 14px; font-weight: 700;">Available Free Time</span>
          <span class="badge badge-secondary" id="slider-label">${activeMinutes} minutes</span>
        </div>
        <input type="range" id="time-slider" min="20" max="240" step="15" value="${activeMinutes}" style="margin: 8px 0 12px;">
        
        <!-- Time Presets -->
        <div style="display: flex; gap: 8px;">
          <button onclick="setTimePreset(30)" style="flex: 1; padding: 7px; font-size: 11px; font-weight: 700; background: ${activeMinutes===30?'var(--primary)':'var(--surface-variant)'}; color: ${activeMinutes===30?'white':'var(--text-secondary)'}; border: none; border-radius: 10px; cursor: pointer; transition: all 0.18s;">30m</button>
          <button onclick="setTimePreset(45)" style="flex: 1; padding: 7px; font-size: 11px; font-weight: 700; background: ${activeMinutes===45?'var(--primary)':'var(--surface-variant)'}; color: ${activeMinutes===45?'white':'var(--text-secondary)'}; border: none; border-radius: 10px; cursor: pointer; transition: all 0.18s;">45m</button>
          <button onclick="setTimePreset(90)" style="flex: 1; padding: 7px; font-size: 11px; font-weight: 700; background: ${activeMinutes===90?'var(--primary)':'var(--surface-variant)'}; color: ${activeMinutes===90?'white':'var(--text-secondary)'}; border: none; border-radius: 10px; cursor: pointer; transition: all 0.18s;">90m</button>
          <button onclick="setTimePreset(180)" style="flex: 1; padding: 7px; font-size: 11px; font-weight: 700; background: ${activeMinutes===180?'var(--primary)':'var(--surface-variant)'}; color: ${activeMinutes===180?'white':'var(--text-secondary)'}; border: none; border-radius: 10px; cursor: pointer; transition: all 0.18s;">3h</button>
        </div>

        <div style="border-top: 1px solid var(--border); margin: 16px 0; padding-top: 14px;">
          <label class="input-label">Simulated Location</label>
          <select id="whatif-location" class="input-field">
            ${AppData.locations.map(loc => `<option ${loc.name===activeLocation?'selected':''}>${loc.name}</option>`).join('')}
          </select>
        </div>
      </div>

      <!-- Recalculated Result -->
      <div class="card" style="border: 2px solid var(--secondary); padding: 18px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
          <span class="badge badge-secondary">🔄 RECALCULATED RESULT</span>
          <span style="font-size: 13px; font-weight: 800; color: var(--secondary);">${dec.totalScore}% Fit</span>
        </div>

        <h3 id="whatif-task-title" style="font-size: 19px; font-weight: 800; color: var(--text-primary); margin-bottom: 4px;">${dec.task.title}</h3>
        <div id="whatif-task-meta" style="font-size: 12px; color: var(--text-secondary); margin-bottom: 14px;">${dec.task.durationMinutes} mins &bull; ${dec.task.locationName}</div>

        <!-- Changed Because -->
        <div style="background: rgba(16,185,129,0.08); border: 1px solid rgba(13,148,136,0.3); border-radius: 12px; padding: 12px; margin-bottom: 16px;">
          <div style="font-size: 10px; font-weight: 800; color: #047857; letter-spacing: 0.5px; margin-bottom: 4px;">YOUR DECISION CHANGED BECAUSE...</div>
          <div id="whatif-reason" style="font-size: 13px; line-height: 1.5; color: #064E3B;">${dec.changeReason}</div>
        </div>

        <button class="btn-primary" style="background: var(--secondary);" onclick="applyWhatIf()">✓ Apply This Simulation to My Plan</button>
      </div>
    </div>
  `;
}

function setupWhatIfListeners() {
  const slider = document.getElementById('time-slider');
  const locationSelect = document.getElementById('whatif-location');

  function updateWhatIf() {
    const mins = parseInt(slider.value);
    const loc = locationSelect.value;
    activeMinutes = mins;
    activeLocation = loc;

    const label = document.getElementById('slider-label');
    if (label) label.textContent = `${mins} minutes`;

    currentDecision = DecisionEngine.evaluateNextAction(mins, loc, activePriority);

    const titleEl = document.getElementById('whatif-task-title');
    const metaEl = document.getElementById('whatif-task-meta');
    const reasonEl = document.getElementById('whatif-reason');

    if (titleEl) titleEl.textContent = currentDecision.task.title;
    if (metaEl) metaEl.textContent = `${currentDecision.task.durationMinutes} mins • ${currentDecision.task.locationName}`;
    if (reasonEl) reasonEl.textContent = currentDecision.changeReason;

    // Update score display
    const scoreSpans = document.querySelectorAll('[data-whatif-score]');
    scoreSpans.forEach(el => el.textContent = `${currentDecision.totalScore}% Fit`);
  }

  if (slider) {
    slider.addEventListener('input', updateWhatIf);
  }
  if (locationSelect) {
    locationSelect.addEventListener('change', updateWhatIf);
  }
}

function setTimePreset(mins) {
  activeMinutes = mins;
  currentDecision = DecisionEngine.evaluateNextAction(activeMinutes, activeLocation, activePriority);
  renderScreen('what_if');
}

function setLocation(loc) {
  activeLocation = loc;
  currentDecision = DecisionEngine.evaluateNextAction(activeMinutes, activeLocation, activePriority);
  renderScreen('what_if');
}

function applyWhatIf() {
  alert(`✅ Applied! "${currentDecision.task.title}" is now your active next step.`);
  renderScreen('home');
}

// ─── 8. SPECIALIZATION ASSESSMENT ──────────────────────────────────────────
function renderAssessmentScreen(step) {
  const p = AppData.specializationProfile;
  const totalSteps = 4;
  const progressPct = ((step) / totalSteps) * 100;

  const stepLabels = ['Academic', 'Technical', 'Interests', 'Priorities'];

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="${step > 0 ? `renderScreen('specialization_assessment', {step: ${step-1}})` : `renderScreen('home')`}">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">SPECIALIZATION ASSESSMENT</div>
      <div style="font-size: 12px; font-weight: 700; color: var(--text-muted);">${step+1}/${totalSteps}</div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Progress Bar -->
      <div style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
          ${stepLabels.map((label, i) => `
            <div style="font-size: 10px; font-weight: ${i <= step ? '800' : '600'}; color: ${i <= step ? 'var(--accent)' : 'var(--text-muted)'}; text-align: center;">${label}</div>
          `).join('')}
        </div>
        <div style="height: 6px; background: var(--border); border-radius: 3px; overflow: hidden;">
          <div style="height: 100%; width: ${((step+1)/totalSteps*100)}%; background: linear-gradient(90deg, var(--accent), var(--primary)); border-radius: 3px; transition: width 0.4s;"></div>
        </div>
      </div>

      <div class="card" style="padding: 20px;">
        ${step === 0 ? `
          <h3 style="font-size: 18px; font-weight: 800; margin-bottom: 4px; letter-spacing: -0.3px;">Academic Profile</h3>
          <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 18px;">Your coursework baselines help evaluate readiness for each specialization branch.</p>
          
          <div class="input-group">
            <label class="input-label">Current CGPA: <strong id="cgpa-display">${p.cgpa} / 10.0</strong></label>
            <input type="range" min="5.0" max="10.0" step="0.1" value="${p.cgpa}" 
              oninput="AppData.specializationProfile.cgpa = parseFloat(this.value); document.getElementById('cgpa-display').textContent = this.value + ' / 10.0'">
          </div>
          
          <div class="input-group">
            <label class="input-label">Strongest Academic Subjects</label>
            <div style="display: flex; gap: 6px; flex-wrap: wrap;">
              ${['DBMS', 'Linear Algebra', 'Python Programming', 'Statistics', 'OOP', 'Networks'].map(s => `
                <span class="chip">${s}</span>
              `).join('')}
            </div>
          </div>
          
          <div class="input-group" style="margin-top: 12px;">
            <label class="input-label">Academic Year</label>
            <select class="input-field">
              <option>1st Year</option><option selected>2nd Year</option><option>3rd Year</option><option>4th Year</option>
            </select>
          </div>
          
          <button class="btn-primary" style="background: var(--accent); margin-top: 6px; box-shadow: 0 4px 12px rgba(139,92,246,0.3);" onclick="renderScreen('specialization_assessment', {step: 1})">Next: Technical Skills →</button>
        ` : step === 1 ? `
          <h3 style="font-size: 18px; font-weight: 800; margin-bottom: 4px;">Technical Skills</h3>
          <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 18px;">Self-rate your technical proficiency across computer science pillars.</p>
          
          ${[
            ['Linear Algebra & Mathematics', 'mathComfort'],
            ['Data Structures & Algorithms', 'dsaKnowledge'],
            ['Databases & SQL', 'databaseKnowledge'],
            ['Systems & Networking', 'networkingKnowledge'],
            ['Statistics & Probability', 'statsComfort'],
          ].map(([label, key]) => `
            <div class="slider-container">
              <div class="slider-header">
                <span>${label}</span>
                <span class="badge badge-primary" id="lbl-${key}">${p[key]}/5</span>
              </div>
              <input type="range" min="1" max="5" value="${p[key]}" 
                oninput="AppData.specializationProfile['${key}'] = parseInt(this.value); document.getElementById('lbl-${key}').textContent = this.value + '/5'">
            </div>
          `).join('')}
          
          <button class="btn-primary" style="background: var(--accent); margin-top: 14px; box-shadow: 0 4px 12px rgba(139,92,246,0.3);" onclick="renderScreen('specialization_assessment', {step: 2})">Next: Interests →</button>
        ` : step === 2 ? `
          <h3 style="font-size: 18px; font-weight: 800; margin-bottom: 4px;">Career Interests</h3>
          <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 18px;">What kind of engineering problems do you want to tackle?</p>
          
          <div class="input-group">
            <label class="input-label">Target Job Role</label>
            <select class="input-field">
              <option selected>Machine Learning Engineer</option>
              <option>Software Development Engineer (SDE)</option>
              <option>Data Scientist / Analyst</option>
              <option>Cloud Infrastructure Architect</option>
              <option>Cybersecurity Analyst</option>
              <option>Research Scientist</option>
            </select>
          </div>
          <div class="input-group">
            <label class="input-label">Preferred Company Type</label>
            <select class="input-field">
              <option selected>Product Company (Google, Microsoft)</option>
              <option>High-Growth Startup</option>
              <option>Research Institution (IIT, NTU)</option>
              <option>Consulting Firm</option>
            </select>
          </div>
          <div class="input-group">
            <label class="input-label">Work Style Preference</label>
            <select class="input-field">
              <option selected>Hybrid — Build + Research</option>
              <option>Pure Engineering / Coding</option>
              <option>Research & Academia</option>
              <option>Leadership & Product Strategy</option>
            </select>
          </div>
          
          <button class="btn-primary" style="background: var(--accent); margin-top: 6px; box-shadow: 0 4px 12px rgba(139,92,246,0.3);" onclick="renderScreen('specialization_assessment', {step: 3})">Next: Priorities →</button>
        ` : `
          <h3 style="font-size: 18px; font-weight: 800; margin-bottom: 4px;">Personal Priorities</h3>
          <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 18px;">What factors weigh most in your university decisions?</p>
          
          ${[
            ['Interest & Passion', 'priorityInterest'],
            ['Salary & Placement', 'prioritySalary'],
            ['Career Flexibility', 'priorityFlexibility'],
            ['Research Depth', 'priorityResearch'],
            ['International Opportunities', 'priorityInternational'],
          ].map(([label, key]) => `
            <div class="slider-container">
              <div class="slider-header">
                <span>${label}</span>
                <span class="badge badge-secondary" id="pri-${key}">${p[key]}/5</span>
              </div>
              <input type="range" min="1" max="5" value="${p[key]}"
                oninput="AppData.specializationProfile['${key}'] = parseInt(this.value); document.getElementById('pri-${key}').textContent = this.value + '/5'">
            </div>
          `).join('')}
          
          <button class="btn-primary" style="background: linear-gradient(135deg, var(--accent), #6D28D9); margin-top: 16px; font-size: 16px; padding: 16px;" onclick="finishAssessment()">
            🚀 Generate My Personalized Analysis
          </button>
        `}
      </div>
    </div>
  `;
}

function finishAssessment() {
  currentSpecializationResult = DecisionEngine.evaluateSpecialization(AppData.specializationProfile);
  renderScreen('specialization_result');
}

// ─── 9. SPECIALIZATION RESULT ────────────────────────────────────────────────
function renderSpecializationResultScreen() {
  const res = currentSpecializationResult;
  const top = res.tracks[0];
  const others = res.tracks.slice(1);

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('specialization_assessment', {step: 3})">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">SPECIALIZATION ANALYSIS</div>
      <button class="icon-btn" onclick="renderScreen('specialization_what_if')" title="What-If Priorities">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20v-6M6 20V10M18 20V4"/></svg>
      </button>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Disclaimer -->
      <div style="background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.35); border-radius: 14px; padding: 12px 14px; margin-bottom: 16px; display: flex; gap: 10px; align-items: flex-start;">
        <span style="font-size: 16px; flex-shrink: 0;">⚠️</span>
        <div style="font-size: 11px; line-height: 1.5; color: #92400E; font-weight: 600;">
          Advisory only — based on information you provided. Does not guarantee employment, salary, internship placement, or career outcomes.
        </div>
      </div>

      <!-- Top Match Hero -->
      <div style="background: linear-gradient(135deg, #4C1D95, #6D28D9, #7C3AED); color: white; border-radius: 22px; padding: 22px; margin-bottom: 16px; box-shadow: 0 14px 30px -8px rgba(109,40,217,0.5);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span class="badge" style="background: rgba(255,255,255,0.2); color: white;">✨ STRONG ALIGNMENT</span>
            <span class="ai-badge">AI Match</span>
          </div>
          <div class="badge-score" style="color: #6D28D9;" class="score-anim">${top.score}%</div>
        </div>
        <h3 style="font-size: 23px; font-weight: 800; margin-bottom: 6px; letter-spacing: -0.5px;">${top.title}</h3>
        <p style="font-size: 13px; line-height: 1.5; opacity: 0.93; margin-bottom: 18px;">${top.desc}</p>
        <button class="btn-white" style="color: #6D28D9;" onclick="renderScreen('roadmap')">View 6-Month Roadmap →</button>
      </div>

      <!-- Why This Pathway -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">WHY THIS PATHWAY ALIGNS WITH YOU</div>
      <div class="card" style="padding: 18px; margin-bottom: 16px;">
        ${[
          ['Interest Fit', 95, 'AI/ML aligns with your stated interests and self-rating'],
          ['Skill Fit', Math.round(AppData.specializationProfile.mathComfort / 5 * 100), `Your math comfort (${AppData.specializationProfile.mathComfort}/5) is key for ML algorithms`],
          ['Academic Fit', Math.round(AppData.specializationProfile.cgpa / 10 * 100), `CGPA ${AppData.specializationProfile.cgpa} exceeds typical threshold`],
          ['Market Alignment', 92, 'ML Engineers in top demand — 2024–2030 growth trajectory'],
        ].map(([label, pct, desc]) => `
          <div class="factor-row">
            <div class="factor-header">
              <span>${label}</span>
              <span style="color: var(--accent); font-weight: 800;">${pct}%</span>
            </div>
            <div class="factor-bar-bg">
              <div class="factor-bar-fill" style="width: ${pct}%; background: linear-gradient(90deg, var(--accent), #A78BFA);"></div>
            </div>
            <div style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">${desc}</div>
          </div>
        `).join('')}
      </div>

      <!-- Skill Gaps -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">SKILL GAPS TO CLOSE NEXT</div>
      <div class="card" style="padding: 16px; margin-bottom: 16px;">
        ${[
          ['🔴', 'Deep Learning (PyTorch & Transformers)'],
          ['🔴', 'Vector Databases & RAG Pipelines'],
          ['🟡', 'Probability & Multivariable Calculus'],
          ['🟡', 'MLOps Deployment (FastAPI + Docker)'],
        ].map(([dot, gap]) => `
          <div style="display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid var(--border);">
            <span style="font-size: 14px; flex-shrink: 0;">${dot}</span>
            <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">${gap}</span>
          </div>
        `).join('')}
      </div>

      <!-- Alternative Tracks -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 10px;">ADDITIONAL EVALUATED PATHWAYS</div>
      ${others.map(o => `
        <div class="card" style="padding: 14px; margin-bottom: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">${o.title}</div>
            <span class="badge ${o.level === 'Different Path' ? 'badge-warning' : 'badge-secondary'}">${o.score}% • ${o.level}</span>
          </div>
          <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.4;">${o.desc}</p>
        </div>
      `).join('')}

      <button class="btn-secondary" style="border-color: var(--accent); color: var(--accent); font-weight: 700; margin-top: 6px;" onclick="renderScreen('specialization_what_if')">
        Explore What-If: Adjust Priorities
      </button>
    </div>
  `;
}

// ─── 10. SPECIALIZATION WHAT-IF ──────────────────────────────────────────────
function renderSpecializationWhatIfScreen() {
  const p = AppData.specializationProfile;
  const res = currentSpecializationResult;

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('specialization_result')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">WHAT-IF: SPECIALIZATION</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <div style="background: linear-gradient(135deg, #4C1D95, #6D28D9); color: white; border-radius: 18px; padding: 14px; margin-bottom: 16px;">
        <div style="font-size: 10px; font-weight: 800; letter-spacing: 0.8px; opacity: 0.8; margin-bottom: 4px;">PRIORITY SIMULATION ENGINE</div>
        <div style="font-size: 13px; line-height: 1.5;">Adjust the sliders to see how changing your priorities would shift your specialization recommendation.</div>
      </div>

      <div class="card" style="padding: 18px; margin-bottom: 16px;">
        ${[
          ['Career Flexibility', 'priorityFlexibility', 'slider-flex', 'label-flex'],
          ['Research Track Preference', 'priorityResearch', 'slider-res', 'label-res'],
          ['Salary & Placement Priority', 'prioritySalary', 'slider-sal', 'label-sal'],
          ['International Opportunities', 'priorityInternational', 'slider-int', 'label-int'],
        ].map(([label, key, sliderId, labelId]) => `
          <div class="slider-container">
            <div class="slider-header">
              <span>${label}</span>
              <span class="badge badge-secondary" id="${labelId}">${p[key]}/5</span>
            </div>
            <input type="range" id="${sliderId}" min="1" max="5" value="${p[key]}">
          </div>
        `).join('')}
      </div>

      <!-- Recalculated Result -->
      <div class="card" style="border: 2px solid var(--accent); padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <span class="badge" style="background: var(--accent-light); color: var(--accent);">🔄 RECALCULATED</span>
          <span id="spec-whatif-score" style="font-size: 13px; font-weight: 800; color: var(--accent);">${res.tracks[0].score}% Match</span>
        </div>
        <h3 id="spec-whatif-title" style="font-size: 20px; font-weight: 800; margin-bottom: 4px; color: var(--text-primary);">${res.tracks[0].title}</h3>
        <p id="spec-whatif-desc" style="font-size: 12px; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.4;">${res.tracks[0].desc}</p>

        <div style="background: rgba(139,92,246,0.08); border: 1px solid var(--accent-light); border-radius: 12px; padding: 12px; margin-bottom: 16px;">
          <div style="font-size: 10px; font-weight: 800; color: #581C87; letter-spacing: 0.5px; margin-bottom: 4px;">RECOMMENDATION CHANGED BECAUSE...</div>
          <div id="spec-whatif-reason" style="font-size: 12px; line-height: 1.5; color: #4A044E;">${res.changeReason}</div>
        </div>

        <button class="btn-primary" style="background: var(--accent);" onclick="renderScreen('roadmap')">View Roadmap for This Track →</button>
      </div>
    </div>
  `;
}

function setupSpecializationWhatIfListeners() {
  const map = [
    ['slider-flex', 'label-flex', 'priorityFlexibility'],
    ['slider-res',  'label-res',  'priorityResearch'],
    ['slider-sal',  'label-sal',  'prioritySalary'],
    ['slider-int',  'label-int',  'priorityInternational'],
  ];

  function update() {
    map.forEach(([sliderId, labelId, key]) => {
      const el = document.getElementById(sliderId);
      if (el) AppData.specializationProfile[key] = parseInt(el.value);
      const lbl = document.getElementById(labelId);
      const s = document.getElementById(sliderId);
      if (lbl && s) lbl.textContent = `${s.value}/5`;
    });

    currentSpecializationResult = DecisionEngine.evaluateSpecialization(AppData.specializationProfile);
    const res = currentSpecializationResult;

    const titleEl = document.getElementById('spec-whatif-title');
    const descEl  = document.getElementById('spec-whatif-desc');
    const scoreEl = document.getElementById('spec-whatif-score');
    const reasonEl= document.getElementById('spec-whatif-reason');

    if (titleEl) titleEl.textContent = res.tracks[0].title;
    if (descEl) descEl.textContent = res.tracks[0].desc;
    if (scoreEl) scoreEl.textContent = `${res.tracks[0].score}% Match`;
    if (reasonEl) reasonEl.textContent = res.changeReason;
  }

  map.forEach(([sliderId]) => {
    const el = document.getElementById(sliderId);
    if (el) el.addEventListener('input', update);
  });
}

// ─── 11. CAREER ROADMAP ──────────────────────────────────────────────────────
function renderRoadmapScreen() {
  const res = currentSpecializationResult;
  const top = res ? res.tracks[0] : { title: 'AI / Machine Learning' };

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('specialization_result')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">6-MONTH ROADMAP</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Track Banner -->
      <div style="background: linear-gradient(135deg, #4C1D95, #6D28D9); color: white; border-radius: 18px; padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 10px; font-weight: 800; letter-spacing: 0.8px; opacity: 0.8; margin-bottom: 4px;">PERSONALIZED TRACK</div>
        <div style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px;">${top.title}</div>
      </div>

      <!-- Disclaimer -->
      <div style="background: var(--surface-variant); border-radius: 12px; padding: 10px 14px; margin-bottom: 16px; font-size: 11px; font-weight: 600; color: var(--text-muted);">
        📊 Demo roadmap with sample market data. For academic planning purposes only.
      </div>

      <!-- Market Info -->
      <div class="card" style="padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); margin-bottom: 8px;">TARGET JOB ROLES</div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px;">
          ${['Machine Learning Engineer', 'AI Research Associate', 'NLP Specialist', 'MLOps Engineer'].map(r => `<span class="badge badge-primary">${r}</span>`).join('')}
        </div>
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); margin-bottom: 8px;">CORE TECHNOLOGIES TO MASTER</div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          ${['Python', 'PyTorch', 'FastAPI', 'Docker', 'Milvus', 'HuggingFace'].map(t => `<span class="badge badge-secondary">${t}</span>`).join('')}
        </div>
      </div>

      <!-- Timeline -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin-bottom: 14px;">ROADMAP TIMELINE</div>

      ${[
        {
          period: 'Month 1–2',
          title: 'Math Foundations & Python Vectorization',
          skills: ['Linear Algebra (3Blue1Brown)', 'NumPy & Pandas', 'Matplotlib Visualization'],
          project: 'Linear Regression from scratch — no scikit-learn',
          milestone: 'GitHub repo with verified vector benchmarks'
        },
        {
          period: 'Month 3–4',
          title: 'Deep Learning & PyTorch Models',
          skills: ['Neural networks & backpropagation', 'CNN & RNN architectures', 'Hugging Face Transformers'],
          project: 'Transformer Document Classifier on custom dataset',
          milestone: 'Live Space on Hugging Face with inference demo'
        },
        {
          period: 'Month 5',
          title: 'Generative AI & MLOps Deployment',
          skills: ['Vector databases (Milvus / ChromaDB)', 'Docker containerization', 'FastAPI REST endpoints'],
          project: 'University Syllabi Q&A Agent with RAG',
          milestone: 'Deployed cloud endpoint with latency logging'
        },
        {
          period: 'Month 6',
          title: 'Interview Prep & Portfolio Polish',
          skills: ['LeetCode Medium (Python/C++)', 'System Design basics (ML pipelines)', 'Behavioral STAR stories'],
          project: 'Polished technical portfolio site',
          milestone: '10+ targeted internship/job applications sent'
        },
      ].map((stage, i) => `
        <div class="timeline-item">
          <div class="timeline-marker">${i+1}</div>
          <div class="timeline-content">
            <span class="badge badge-primary" style="margin-bottom: 7px;">${stage.period}</span>
            <div style="font-size: 14px; font-weight: 800; margin-bottom: 8px; color: var(--text-primary);">${stage.title}</div>
            <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.5;">
              <div style="font-weight: 700; color: var(--text-muted); font-size: 10px; letter-spacing: 0.5px; margin-bottom: 4px;">SKILLS</div>
              ${stage.skills.map(s => `<div style="margin-bottom: 3px;">• ${s}</div>`).join('')}
              <div style="margin-top: 8px; font-weight: 700; color: var(--text-muted); font-size: 10px; letter-spacing: 0.5px;">PROJECT</div>
              <div style="margin: 4px 0 6px;">🛠️ ${stage.project}</div>
              <div style="font-weight: 700; color: var(--text-muted); font-size: 10px; letter-spacing: 0.5px;">MILESTONE</div>
              <div style="margin-top: 4px;">🏆 ${stage.milestone}</div>
            </div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

// ─── 12. CAMPUS MAP ──────────────────────────────────────────────────────────
function renderCampusMapScreen() {
  return `
    <div class="screen-header">
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">CAMPUS WAYFINDING</div>
      <button class="icon-btn" onclick="renderScreen('home')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Current Location -->
      <div class="card" style="display: flex; align-items: center; gap: 10px; padding: 12px 14px; margin-bottom: 14px;">
        <span style="font-size: 20px;">📍</span>
        <div style="flex: 1; font-size: 12px;">
          <span style="color: var(--text-muted);">You are at: </span>
          <strong id="current-loc-display">${activeLocation}</strong>
        </div>
        <span class="badge badge-secondary">Live</span>
      </div>

      <!-- Map Canvas -->
      <div class="campus-map-box" id="campus-map">
        <!-- SVG background: roads and lawns -->
        <svg width="100%" height="100%" viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg">
          <!-- Green lawns -->
          <ellipse cx="80" cy="70" rx="60" ry="40" fill="#DCFCE7" opacity="0.8"/>
          <ellipse cx="300" cy="200" rx="70" ry="50" fill="#DCFCE7" opacity="0.6"/>
          <!-- Main roads -->
          <rect x="0" y="100" width="400" height="16" fill="#CBD5E1" rx="0"/>
          <rect x="170" y="0" width="16" height="300" fill="#CBD5E1" rx="0"/>
          <!-- Path highlights -->
          <line x1="80" y1="116" x2="170" y2="116" stroke="#93C5FD" stroke-width="3" stroke-dasharray="6,4" opacity="0.7"/>
          <line x1="186" y1="150" x2="186" y2="250" stroke="#93C5FD" stroke-width="3" stroke-dasharray="6,4" opacity="0.5"/>
          <!-- Building rectangles -->
          <rect x="30" y="130" width="60" height="40" rx="6" fill="#E0E7FF" stroke="#A5B4FC" stroke-width="1.5"/>
          <rect x="200" y="30" width="55" height="45" rx="6" fill="#FEF3C7" stroke="#FCD34D" stroke-width="1.5"/>
          <rect x="230" y="130" width="60" height="40" rx="6" fill="#D1FAE5" stroke="#6EE7B7" stroke-width="1.5"/>
          <rect x="90" y="190" width="55" height="40" rx="6" fill="#FCE7F3" stroke="#F9A8D4" stroke-width="1.5"/>
          <rect x="310" y="100" width="60" height="50" rx="6" fill="#E0E7FF" stroke="#A5B4FC" stroke-width="1.5"/>
        </svg>
        <!-- Location Pins -->
        ${AppData.locations.map(loc => {
          const isCurrent = loc.name === activeLocation;
          return `
            <div class="map-pin ${isCurrent ? 'current' : ''}" 
                 style="left: ${loc.x * 100}%; top: ${loc.y * 100}%;"
                 onclick="selectCampusLocation('${loc.name}')">
              <span>${isCurrent ? '📍' : '🏢'}</span>
              <span>${loc.name.split(' ').slice(0,2).join(' ')} (${loc.travelTimeMinutes}m)</span>
            </div>
          `;
        }).join('')}
      </div>

      <!-- Location List -->
      <div style="font-size: 11px; font-weight: 800; letter-spacing: 0.8px; color: var(--text-muted); margin: 14px 0 10px;">ALL CAMPUS LOCATIONS</div>
      ${AppData.locations.map(loc => `
        <div class="card" style="padding: 12px 14px; display: flex; align-items: center; gap: 12px; cursor: pointer; border: ${loc.name === activeLocation ? '2px solid var(--secondary)' : '1px solid var(--border)'};" 
             onclick="selectCampusLocation('${loc.name}')">
          <div style="font-size: 20px;">${loc.name === activeLocation ? '📍' : '🏢'}</div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">${loc.name}</div>
            <div style="font-size: 11px; color: var(--text-secondary);">${loc.desc}</div>
          </div>
          <span class="badge ${loc.travelTimeMinutes === 0 ? 'badge-secondary' : 'badge-primary'}">${loc.travelTimeMinutes === 0 ? 'Here' : loc.travelTimeMinutes + 'm walk'}</span>
        </div>
      `).join('')}
    </div>
  `;
}

function setupMapListeners() {
  // Pins already have onclick attached inline
}

function selectCampusLocation(locName) {
  activeLocation = locName;
  currentDecision = DecisionEngine.evaluateNextAction(activeMinutes, activeLocation, activePriority);
  renderScreen('map');
}

// ─── 13. DECISION HISTORY ────────────────────────────────────────────────────
function renderHistoryScreen() {
  const historyItems = [
    { badge: 'badge-primary', label: 'ACTIVE STEP', time: '9:30 AM Today', title: 'Complete DBMS Assignment', desc: 'Due tonight 11:59 PM. Library is 6 mins away. Score: 87/100.' },
    { badge: 'badge-secondary', label: 'SIMULATION TEST', time: 'Yesterday 4:00 PM', title: 'Revise DBMS Unit 3 (35m)', desc: 'Recommended when time was constrained to 45 minutes. Score: 78/100.' },
    { badge: '', label: 'SPECIALIZATION', time: '2 days ago', title: 'AI / Machine Learning (88% Match)', desc: 'Strong Alignment confirmed with 6-month preparation roadmap generated.', style: 'background: var(--accent-light); color: var(--accent);' },
    { badge: 'badge-warning', label: 'SKIPPED', time: '3 days ago', title: 'Software Engineering SRS Draft', desc: 'Skipped due to higher-priority DBMS deadline. Rescheduled for tomorrow.' },
  ];

  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('home')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">DECISION AUDIT LOG</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 14px; line-height: 1.5;">
        Complete log of all decisions made or simulated by UNI STEP.
      </div>
      ${historyItems.map((item, i) => `
        <div class="card" style="padding: 14px; border-left: 4px solid ${i === 0 ? 'var(--primary)' : i === 2 ? 'var(--accent)' : 'var(--border)'};">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span class="badge ${item.badge}" style="${item.style || ''}">${item.label}</span>
            <span style="font-size: 10px; color: var(--text-muted); font-weight: 600;">${item.time}</span>
          </div>
          <h4 style="font-size: 14px; font-weight: 800; margin-bottom: 4px; color: var(--text-primary);">${item.title}</h4>
          <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.4;">${item.desc}</p>
        </div>
      `).join('')}
    </div>
  `;
}

// ─── 14. PROFILE ─────────────────────────────────────────────────────────────
function renderProfileScreen() {
  const p = AppData.profile;
  return `
    <div class="screen-header">
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">STUDENT PROFILE</div>
      <button class="icon-btn" onclick="renderScreen('settings')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
      </button>
    </div>

    <div style="padding: 12px 18px 24px;">
      <!-- Avatar Card -->
      <div class="card" style="padding: 20px; display: flex; align-items: center; gap: 16px;">
        <div style="width: 64px; height: 64px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-container), var(--primary-light)); color: var(--primary); font-size: 26px; font-weight: 900; display: flex; align-items: center; justify-content: center; border: 2px solid var(--primary-light);">
          ${p.name[0]}
        </div>
        <div>
          <h3 style="font-size: 19px; font-weight: 800; letter-spacing: -0.3px;">${p.name}</h3>
          <div style="font-size: 12px; color: var(--text-secondary); margin-top: 2px;">@${p.username} &bull; ${p.email}</div>
          <div class="badge badge-primary" style="margin-top: 6px;">${p.university} &bull; ${p.year}</div>
        </div>
      </div>

      <!-- Stats Grid -->
      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 16px;">
        ${[
          ['CGPA', p.cgpa, 'Target 9.0', 'var(--primary)'],
          ['FREE TIME', `${activeMinutes}m`, 'Current block', 'var(--secondary)'],
          ['FOCUS', 'High', 'Academic', 'var(--accent)'],
        ].map(([label, value, sub, color]) => `
          <div class="card" style="padding: 12px; text-align: center;">
            <div style="font-size: 10px; color: var(--text-muted); font-weight: 700; letter-spacing: 0.5px;">${label}</div>
            <div style="font-size: 20px; font-weight: 900; color: ${color}; margin: 4px 0;">${value}</div>
            <div style="font-size: 9px; color: var(--text-secondary);">${sub}</div>
          </div>
        `).join('')}
      </div>

      <!-- Skills -->
      <div class="card" style="padding: 14px;">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 10px;">TECHNICAL SKILLS</div>
        <div style="display: flex; flex-wrap: wrap; gap: 6px;">
          ${p.skills.map(s => `<span class="chip">${s}</span>`).join('')}
        </div>
      </div>

      <!-- Interests -->
      <div class="card" style="padding: 14px;">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 10px;">INTERESTS</div>
        <div style="display: flex; flex-wrap: wrap; gap: 6px;">
          ${p.interests.map(i => `<span class="chip" style="background: var(--secondary-container); color: #0F766E;">${i}</span>`).join('')}
        </div>
      </div>

      <button class="btn-secondary" onclick="renderScreen('settings')">Settings &amp; Preferences →</button>
    </div>
  `;
}

// ─── 15. SETTINGS ────────────────────────────────────────────────────────────
function renderSettingsScreen() {
  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('profile')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">SETTINGS</div>
      <div style="width: 36px;"></div>
    </div>

    <div style="padding: 12px 18px 24px;">
      <div class="card" style="padding: 16px; margin-bottom: 14px;">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 14px;">NOTIFICATION PREFERENCES</div>
        ${[
          ['Next Step Recommendations', true],
          ['Urgent Deadline Alerts (&lt;6h)', true],
          ['Geofenced Walking Time Sync', true],
          ['Weekly Progress Digest', false],
        ].map(([label, checked]) => `
          <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border);">
            <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">${label}</span>
            <input type="checkbox" ${checked ? 'checked' : ''} style="accent-color: var(--primary); width: 18px; height: 18px; cursor: pointer;">
          </div>
        `).join('')}
      </div>

      <div class="card" style="padding: 16px; margin-bottom: 16px;">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 14px;">LEGAL &amp; COMPLIANCE</div>
        <div style="padding: 10px 0; border-bottom: 1px solid var(--border); cursor: pointer;" onclick="renderScreen('terms')">
          <span style="font-size: 13px; font-weight: 700; color: var(--text-primary);">Terms &amp; Conditions →</span>
        </div>
        <div style="padding: 10px 0; cursor: pointer;" onclick="renderScreen('privacy')">
          <span style="font-size: 13px; font-weight: 700; color: var(--text-primary);">Privacy Policy →</span>
        </div>
      </div>

      <div class="card" style="padding: 14px; margin-bottom: 16px; background: var(--surface-variant);">
        <div style="font-size: 11px; font-weight: 800; color: var(--text-muted); letter-spacing: 0.5px; margin-bottom: 6px;">APP VERSION</div>
        <div style="font-size: 13px; font-weight: 600;">UNI STEP v1.0.0 — Hackathon MVP</div>
        <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">Built for smart campus decision support</div>
      </div>

      <button class="btn-secondary" style="border-color: var(--error); color: var(--error); font-weight: 700;" onclick="if(confirm('Log out of UNI STEP?')) renderScreen('welcome');">
        Logout of UNI STEP
      </button>
    </div>
  `;
}

// ─── 16. TERMS & CONDITIONS ──────────────────────────────────────────────────
function renderTermsScreen() {
  const from = previousScreen === 'terms' ? 'welcome' : (previousScreen || 'welcome');
  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('${from}')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">TERMS &amp; CONDITIONS</div>
      <div style="width: 36px;"></div>
    </div>
    <div style="padding: 12px 18px 24px; font-size: 13px; line-height: 1.6; color: var(--text-secondary);">
      <div style="background: var(--warning-container); border: 1px solid var(--warning); border-radius: 14px; padding: 14px; margin-bottom: 18px; color: #92400E; font-weight: 600; font-size: 12px; line-height: 1.5;">
        <strong>⚠️ Important Disclaimer:</strong> UNI STEP recommendations are for advisory decision support only and do not guarantee academic grades, placement offers, internship selection, employment, or salary levels. All data shown is simulated for demonstration purposes.
      </div>
      <h4 style="color: var(--text-primary); margin: 14px 0 6px; font-size: 14px;">1. Purpose of the Service</h4>
      <p>UNI STEP turns scattered student information (timetables, exams, assignments, campus locations) into a single personalized next action using multi-attribute decision analysis.</p>
      <h4 style="color: var(--text-primary); margin: 14px 0 6px; font-size: 14px;">2. User Responsibility</h4>
      <p>Students remain solely responsible for attending required lectures, verifying assignment deadlines with course instructors, and making all academic decisions independently.</p>
      <h4 style="color: var(--text-primary); margin: 14px 0 6px; font-size: 14px;">3. No Guarantee of Outcome</h4>
      <p>Specialization recommendations, career roadmaps, and decision scores are algorithmic suggestions based on user-provided inputs. They represent decision support, not guaranteed career or academic outcomes.</p>
      <h4 style="color: var(--text-primary); margin: 14px 0 6px; font-size: 14px;">4. Hackathon Context</h4>
      <p>This application is a hackathon MVP. All student data is simulated. No real personal or academic data is collected or stored.</p>
    </div>
  `;
}

// ─── 17. PRIVACY POLICY ──────────────────────────────────────────────────────
function renderPrivacyScreen() {
  const from = previousScreen === 'privacy' ? 'settings' : (previousScreen || 'settings');
  return `
    <div class="screen-header">
      <button class="icon-btn" onclick="renderScreen('${from}')">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </button>
      <div style="font-size: 15px; font-weight: 800; color: var(--text-primary);">PRIVACY POLICY</div>
      <div style="width: 36px;"></div>
    </div>
    <div style="padding: 12px 18px 24px; font-size: 13px; line-height: 1.6; color: var(--text-secondary);">
      <h4 style="color: var(--text-primary); margin: 0 0 8px; font-size: 14px;">🔒 Student Data Protection</h4>
      <p style="margin-bottom: 14px;">UNI STEP processes academic schedules, grades, and campus location proximity strictly within your personal device session to calculate decision scores. No server-side storage occurs in the hackathon MVP.</p>
      <h4 style="color: var(--text-primary); margin: 0 0 8px; font-size: 14px;">🚫 No Third-Party Sharing</h4>
      <p style="margin-bottom: 14px;">Your academic deadlines, attendance metrics, and specialization preferences are never sold to ad networks, shared with peer students, or transmitted to third-party analytics services.</p>
      <h4 style="color: var(--text-primary); margin: 0 0 8px; font-size: 14px;">📱 Local Session Only</h4>
      <p style="margin-bottom: 14px;">All decision engine computations run entirely in your browser. Closing the app clears all temporary session data.</p>
      <h4 style="color: var(--text-primary); margin: 0 0 8px; font-size: 14px;">📧 Contact</h4>
      <p>For privacy concerns: <strong>privacy@unistep.app</strong> (demo contact — not monitored in hackathon version)</p>
    </div>
  `;
}

// ═══════════════════════════════════════════════════
// START APPLICATION
// ═══════════════════════════════════════════════════
window.addEventListener('DOMContentLoaded', init);
