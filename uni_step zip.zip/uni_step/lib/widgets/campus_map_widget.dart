import 'package:flutter/material.dart';
import '../models/campus_location.dart';
import '../theme/app_colors.dart';

class CampusMapWidget extends StatelessWidget {
  final List<CampusLocation> locations;
  final CampusLocation? selectedLocation;
  final String currentLocationId;
  final ValueChanged<CampusLocation> onSelectLocation;

  const CampusMapWidget({
    super.key,
    required this.locations,
    required this.selectedLocation,
    required this.currentLocationId,
    required this.onSelectLocation,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 340,
      decoration: BoxDecoration(
        color: const Color(0xFFF1F5F9),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border, width: 1.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            // Campus background styling / pathways
            CustomPaint(
              size: Size.infinite,
              painter: _CampusGridPainter(),
            ),

            // Live status badge
            Positioned(
              top: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.92),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 4),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: AppColors.success,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'SRM AP Campus Grid • Demo Live',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    ),
                  ],
                ),
              ),
            ),

            // Location Pins
            LayoutBuilder(
              builder: (context, constraints) {
                return Stack(
                  children: locations.map((loc) {
                    final isCurrent = loc.name.toLowerCase().contains('academic block 3') ||
                        loc.id == currentLocationId;
                    final isSelected = selectedLocation?.id == loc.id;

                    final leftPos = loc.x * (constraints.maxWidth - 50);
                    final topPos = loc.y * (constraints.maxHeight - 60) + 20;

                    return Positioned(
                      left: leftPos,
                      top: topPos,
                      child: GestureDetector(
                        onTap: () => onSelectLocation(loc),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.primary
                                : isCurrent
                                    ? AppColors.secondary
                                    : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: (isSelected ? AppColors.primary : Colors.black).withOpacity(0.2),
                                blurRadius: isSelected ? 8 : 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                            border: Border.all(
                              color: isSelected ? Colors.white : AppColors.border,
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                isCurrent
                                    ? Icons.my_location
                                    : _getCategoryIcon(loc.category),
                                size: 14,
                                color: isSelected || isCurrent ? Colors.white : AppColors.primary,
                              ),
                              const SizedBox(width: 4),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    loc.name,
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w700,
                                      color: isSelected || isCurrent ? Colors.white : AppColors.textPrimary,
                                    ),
                                  ),
                                  Text(
                                    isCurrent ? 'You are here' : '${loc.travelTimeMinutes} min walk',
                                    style: TextStyle(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w500,
                                      color: isSelected || isCurrent
                                          ? Colors.white.withOpacity(0.85)
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'study':
        return Icons.menu_book;
      case 'lab':
        return Icons.computer;
      case 'dining':
        return Icons.local_cafe;
      case 'events':
        return Icons.theater_comedy;
      case 'recreation':
        return Icons.fitness_center;
      default:
        return Icons.location_on;
    }
  }
}

class _CampusGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final roadPaint = Paint()
      ..color = const Color(0xFFCBD5E1)
      ..strokeWidth = 14
      ..style = PaintingStyle.stroke;

    final pathwayPaint = Paint()
      ..color = const Color(0xFFE2E8F0)
      ..strokeWidth = 6
      ..style = PaintingStyle.stroke;

    final greenPaint = Paint()
      ..color = const Color(0xFFDCFCE7).withOpacity(0.6)
      ..style = PaintingStyle.fill;

    // Green lawns
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(20, 30, size.width * 0.35, 70), const Radius.circular(16)),
      greenPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromLTWH(size.width * 0.55, 120, size.width * 0.4, 90), const Radius.circular(16)),
      greenPaint,
    );

    // Main Spine Avenue
    final mainRoad = Path()
      ..moveTo(size.width * 0.1, size.height * 0.35)
      ..lineTo(size.width * 0.9, size.height * 0.35);
    canvas.drawPath(mainRoad, roadPaint);

    // Cross connecting Boulevard
    final crossRoad = Path()
      ..moveTo(size.width * 0.45, 10)
      ..lineTo(size.width * 0.45, size.height - 10);
    canvas.drawPath(crossRoad, roadPaint);

    // Diagonal Walkways
    final walkPath = Path()
      ..moveTo(size.width * 0.2, size.height * 0.75)
      ..lineTo(size.width * 0.65, size.height * 0.35)
      ..lineTo(size.width * 0.8, size.height * 0.65);
    canvas.drawPath(walkPath, pathwayPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
