import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../utils/constants.dart';
import '../app/app_state.dart';
import '../models/specialization_model.dart';
import '../widgets/factor_bar.dart';
import 'specialization_what_if_screen.dart';
import 'career_roadmap_screen.dart';
import 'specialization_questionnaire_screen.dart';

class SpecializationResultScreen extends StatelessWidget {
  final AppState appState;

  const SpecializationResultScreen({super.key, required this.appState});

  @override
  Widget build(BuildContext context) {
    final results = appState.specializationResults;
    if (results.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('YOUR SPECIALIZATION ANALYSIS')),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('No specialization analysis yet.'),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SpecializationQuestionnaireScreen(appState: appState),
                    ),
                  );
                },
                child: const Text('Take Assessment'),
              ),
            ],
          ),
        ),
      );
    }

    final topMatch = results.first;
    final alsoConsider = results.where((r) => r.alignmentLevel == 'Also Consider').toList();
    final differentPath = results.where((r) => r.alignmentLevel == 'Different Path').toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('YOUR SPECIALIZATION ANALYSIS'),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'What-If Priorities',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SpecializationWhatIfScreen(appState: appState),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Prominent Advisory Disclaimer Card (Strict Hackathon Requirement)
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.warningContainer.withOpacity(0.4),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.warning.withOpacity(0.5)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.info_outline, color: Color(0xFFB45309), size: 20),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      AppConstants.disclaimerText,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF92400E),
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // PRIMARY HERO SPECIALIZATION MATCH
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: AppColors.specializationGradient,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.workspace_premium, color: Colors.white, size: 14),
                            SizedBox(width: 4),
                            Text(
                              'STRONG ALIGNMENT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${topMatch.matchPercentage}% Match',
                          style: const TextStyle(
                            color: Color(0xFF6D28D9),
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(
                    topMatch.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    topMatch.summaryExplanation,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 18),
                  ElevatedButton(
                    onPressed: () {
                      appState.setSelectedSpecialization(topMatch);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CareerRoadmapScreen(
                            appState: appState,
                            option: topMatch,
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF6D28D9),
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('View 6-Month Roadmap', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                        SizedBox(width: 6),
                        Icon(Icons.arrow_forward, size: 16),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // WHY: FACTOR BREAKDOWN
            const Text(
              'WHY THIS PATHWAY ALIGNS WITH YOU',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: topMatch.factors.entries.map((entry) {
                  return FactorBar(
                    label: entry.key,
                    score: entry.value,
                    barColor: AppColors.accent,
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            // YOUR SKILL GAPS
            const Text(
              'YOUR SKILL GAPS TO CLOSE',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: topMatch.skillGaps.map((gap) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10.0),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: AppColors.errorContainer,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Icon(Icons.trending_up, size: 14, color: AppColors.error),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            gap,
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),

            // ALSO CONSIDER (Runner-up)
            if (alsoConsider.isNotEmpty) ...[
              const Text(
                'ALSO CONSIDER',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 10),
              ...alsoConsider.map((opt) => _buildSecondaryOptionCard(context, opt, false)),
              const SizedBox(height: 16),
            ],

            // DIFFERENT PATH
            if (differentPath.isNotEmpty) ...[
              const Text(
                'DIFFERENT PATH',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 10),
              ...differentPath.map((opt) => _buildSecondaryOptionCard(context, opt, true)),
              const SizedBox(height: 16),
            ],

            // WHAT-IF LAUNCHER
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.tune, color: AppColors.accent, size: 24),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('What-If: Priority Adjustments', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                        Text('See how valuing Salary or Flexibility shifts your recommendation', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SpecializationWhatIfScreen(appState: appState),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('Tweak', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildSecondaryOptionCard(BuildContext context, SpecializationOption option, bool isDifferent) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                option.title,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
              ),
              Text(
                '${option.matchPercentage}%',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: isDifferent ? AppColors.textMuted : AppColors.secondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            option.summaryExplanation,
            style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 12),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () {
                appState.setSelectedSpecialization(option);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CareerRoadmapScreen(
                      appState: appState,
                      option: option,
                    ),
                  ),
                );
              },
              child: const Text('Explore Roadmap →'),
            ),
          ),
        ],
      ),
    );
  }
}
