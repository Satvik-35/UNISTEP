import '../models/task_item.dart';
import '../models/decision_item.dart';
import '../models/specialization_model.dart';
import '../models/campus_location.dart';
import '../models/student_profile.dart';
import '../data/demo_data.dart';

abstract class FirestoreService {
  Future<List<TaskItem>> getTasks();
  Future<void> addTask(TaskItem task);
  Future<void> updateTask(TaskItem task);
  Future<List<DecisionItem>> getDecisionHistory();
  Future<void> recordDecision(DecisionItem decision);
  Future<List<CampusLocation>> getCampusLocations();
  Future<SpecializationProfile> getSpecializationProfile();
  Future<void> saveSpecializationProfile(SpecializationProfile profile);
  bool get isFirestoreConnected;
}

class MockFirestoreService implements FirestoreService {
  final List<TaskItem> _tasks = List.from(DemoData.initialTasks);
  final List<DecisionItem> _history = [];
  final List<CampusLocation> _locations = List.from(DemoData.campusLocations);
  SpecializationProfile _specializationProfile = SpecializationProfile();

  @override
  bool get isFirestoreConnected => false; // Fallback to local high-performance store

  @override
  Future<List<TaskItem>> getTasks() async {
    return List.unmodifiable(_tasks);
  }

  @override
  Future<void> addTask(TaskItem task) async {
    _tasks.add(task);
  }

  @override
  Future<void> updateTask(TaskItem task) async {
    final idx = _tasks.indexWhere((t) => t.id == task.id);
    if (idx != -1) {
      _tasks[idx] = task;
    }
  }

  @override
  Future<List<DecisionItem>> getDecisionHistory() async {
    return List.unmodifiable(_history);
  }

  @override
  Future<void> recordDecision(DecisionItem decision) async {
    _history.insert(0, decision);
  }

  @override
  Future<List<CampusLocation>> getCampusLocations() async {
    return List.unmodifiable(_locations);
  }

  @override
  Future<SpecializationProfile> getSpecializationProfile() async {
    return _specializationProfile;
  }

  @override
  Future<void> saveSpecializationProfile(SpecializationProfile profile) async {
    _specializationProfile = profile;
  }
}
