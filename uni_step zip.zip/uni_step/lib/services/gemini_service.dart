import '../models/decision_item.dart';
import '../models/specialization_model.dart';
import '../models/student_profile.dart';

abstract class GeminiService {
  Future<String> generateDecisionExplanation(DecisionItem decision, StudentProfile profile);
  Future<String> answerDecisionQuery(String query, DecisionItem currentDecision, StudentProfile profile);
  Future<String> generateSpecializationInsights(SpecializationOption option, SpecializationProfile profile);
  bool get isGeminiLiveConnected;
}

class MockGeminiService implements GeminiService {
  final String? apiKey;

  MockGeminiService({this.apiKey});

  @override
  bool get isGeminiLiveConnected => apiKey != null && apiKey!.isNotEmpty;

  @override
  Future<String> generateDecisionExplanation(DecisionItem decision, StudentProfile profile) async {
    // If Gemini API is not connected, use the local structured reasoning generator
    await Future.delayed(const Duration(milliseconds: 400));
    final task = decision.recommendedTask;
    return 'Based on your academic schedule at ${profile.university}, prioritizing "${task.title}" is the optimal strategic move. '
        'Because your DBMS exam is only ${task.examProximityDays} days away and this assignment accounts for crucial marks, '
        'completing it within your current ${profile.currentAvailableMinutes}-minute window at the ${task.locationName} guarantees '
        'peace of mind and prevents late-night academic strain.';
  }

  @override
  Future<String> answerDecisionQuery(String query, DecisionItem currentDecision, StudentProfile profile) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final lower = query.toLowerCase();

    if (lower.contains('club') || lower.contains('event')) {
      return 'The AI Club event starts at 5:30 PM in Auditorium C. If you start your 60-minute DBMS assignment right now, you will finish by 5:10 PM, leaving you 20 minutes to comfortably walk over to Auditorium C without rushing.';
    }

    if (lower.contains('exam') || lower.contains('study')) {
      return 'Your DBMS exam is in 3 days. Completing the assignment now doubles as targeted exam preparation because it covers Relational Algebra and Normalization which carry high marks in section B.';
    }

    if (lower.contains('tired') || lower.contains('break')) {
      return 'If you feel low energy, take a 10-minute walk to the Campus Cafeteria first for a green tea, then sit down at Central Library for 50 minutes of focused assignment completion.';
    }

    return 'UNI STEP analyzed your timetable: Taking 60 minutes for "${currentDecision.recommendedTask.title}" right now yields the highest academic return with zero deadline penalties.';
  }

  @override
  Future<String> generateSpecializationInsights(SpecializationOption option, SpecializationProfile profile) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return 'Analysis for ${profile.cgpa} CGPA & ${profile.desiredRole} goal: ${option.title} matches your mathematical comfort and desire to work in ${profile.companyType} engineering. Focus on closing the gap in ${option.skillGaps.first} during your next semester.';
  }
}
