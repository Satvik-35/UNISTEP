import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class FactorBar extends StatelessWidget {
  final String label;
  final double score; // 0.0 to 1.0
  final String? subtitle;
  final Color? barColor;

  const FactorBar({
    super.key,
    required this.label,
    required this.score,
    this.subtitle,
    this.barColor,
  });

  @override
  Widget build(BuildContext context) {
    final percentage = (score * 100).round();
    final effectiveColor = barColor ??
        (score >= 0.85
            ? AppColors.primary
            : score >= 0.70
                ? AppColors.secondary
                : AppColors.warning);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                '$percentage%',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: effectiveColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: score.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: AppColors.border,
              valueColor: AlwaysStoppedAnimation<Color>(effectiveColor),
            ),
          ),
          if (subtitle != null && subtitle!.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              subtitle!,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
