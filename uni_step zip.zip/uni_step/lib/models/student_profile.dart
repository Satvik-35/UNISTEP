class StudentProfile {
  final String id;
  String name;
  String username;
  String email;
  String university;
  String year;
  double cgpa;
  List<String> interests;
  List<String> skills;
  int currentAvailableMinutes;
  String currentLocation;
  String academicPriority; // "High", "Medium", "Balanced"
  String careerPriority; // "High", "Medium", "Balanced"

  StudentProfile({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    required this.university,
    required this.year,
    required this.cgpa,
    required this.interests,
    required this.skills,
    this.currentAvailableMinutes = 90,
    this.currentLocation = 'Academic Block 3',
    this.academicPriority = 'High',
    this.careerPriority = 'Medium',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'username': username,
      'email': email,
      'university': university,
      'year': year,
      'cgpa': cgpa,
      'interests': interests,
      'skills': skills,
      'currentAvailableMinutes': currentAvailableMinutes,
      'currentLocation': currentLocation,
      'academicPriority': academicPriority,
      'careerPriority': careerPriority,
    };
  }

  factory StudentProfile.fromMap(Map<String, dynamic> map) {
    return StudentProfile(
      id: map['id'] ?? 'user_1',
      name: map['name'] ?? 'Rahul',
      username: map['username'] ?? 'rahul_srm',
      email: map['email'] ?? 'rahul@srm.edu.in',
      university: map['university'] ?? 'SRM University AP',
      year: map['year'] ?? '2nd Year',
      cgpa: (map['cgpa'] as num?)?.toDouble() ?? 8.7,
      interests: List<String>.from(map['interests'] ?? ['AI', 'Software Development']),
      skills: List<String>.from(map['skills'] ?? ['Python', 'C++', 'Basic SQL']),
      currentAvailableMinutes: map['currentAvailableMinutes']?.toInt() ?? 90,
      currentLocation: map['currentLocation'] ?? 'Academic Block 3',
      academicPriority: map['academicPriority'] ?? 'High',
      careerPriority: map['careerPriority'] ?? 'Medium',
    );
  }
}
