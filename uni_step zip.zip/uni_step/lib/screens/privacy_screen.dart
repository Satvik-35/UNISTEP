import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.secondaryContainer.withOpacity(0.5),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.secondaryLight.withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.shield_outlined, color: AppColors.secondary, size: 24),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Student Data Privacy & Integrity Commitment',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF134E4A),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildSection(
              title: '1. What Information UNI STEP Collects',
              content:
                  'To personalize daily decisions and career assessments, UNI STEP processes:\n'
                  '• Profile: Name, university, branch, year, and cumulative CGPA.\n'
                  '• Academic Context: Course timetables, assignment deadlines, and exam dates.\n'
                  '• Location & Movement: On-campus building proximity to compute walking times.\n'
                  '• Career Preferences: Technical self-ratings, project history, and career goals.',
            ),
            _buildSection(
              title: '2. How Your Data Is Used',
              content:
                  'Your data is exclusively processed to:\n'
                  '• Calculate the single best next action (Daily Decision Engine).\n'
                  '• Provide transparent trade-off and gain explanations.\n'
                  '• Map your technical profile to 6-month career preparation roadmaps.\n'
                  'Your data is never sold to third-party ad networks or brokers.',
            ),
            _buildSection(
              title: '3. Student-to-Student Isolation',
              content:
                  'Your academic schedule, task completion percentages, and grades are private to your session. No other student or peer can access your personal decisions.',
            ),
            _buildSection(
              title: '4. Account Control & Data Deletion',
              content:
                  'You retain complete control. You can clear your decision history, update your academic metrics, or permanently delete your account directly from the Settings menu at any time.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: const TextStyle(
              fontSize: 14,
              height: 1.5,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
