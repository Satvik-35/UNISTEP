// UNI STEP Decision Engine — Client Port
const AppData = {
  profile: {
    name: 'Rahul',
    username: 'rahul_srm',
    email: 'rahul@srm.edu.in',
    university: 'SRM University AP',
    year: '2nd Year',
    cgpa: 8.7,
    interests: ['AI / Machine Learning', 'Software Engineering', 'System Design'],
    skills: ['Python', 'C++', 'Basic SQL', 'Git'],
    currentAvailableMinutes: 90,
    currentLocation: 'Academic Block 3',
    academicPriority: 'High',
  },

  tasks: [
    {
      id: 'task_dbms_assign',
      title: 'Complete DBMS Assignment',
      type: 'assignment',
      durationMinutes: 60,
      dueText: 'Due tonight (11:59 PM)',
      deadlineHoursLeft: 4.5,
      academicImpact: 95,
      examProximityDays: 3,
      locationName: 'Central Library',
      travelTimeMinutes: 6,
      completionPercent: 60,
      details: 'Finish SQL query optimization problems and Normalization worksheet (1NF to BCNF).',
      courseCode: 'CSE 204: Database Systems',
    },
    {
      id: 'task_dbms_revision',
      title: 'Revise DBMS Unit 3 (Indexing & Transactions)',
      type: 'revision',
      durationMinutes: 35,
      dueText: 'Exam in 3 days',
      deadlineHoursLeft: 72.0,
      academicImpact: 82,
      examProximityDays: 3,
      locationName: 'Academic Block 3 Lounge',
      travelTimeMinutes: 2,
      completionPercent: 20,
      details: 'Review B+ Trees search algorithm and ACID transaction states before midterms.',
      courseCode: 'CSE 204: Database Systems',
    },
    {
      id: 'task_ai_club',
      title: 'Attend AI Club Workshop',
      type: 'clubEvent',
      durationMinutes: 75,
      dueText: 'Starts at 5:30 PM today',
      deadlineHoursLeft: 2.0,
      academicImpact: 45,
      examProximityDays: 14,
      locationName: 'Auditorium C',
      travelTimeMinutes: 10,
      completionPercent: 0,
      details: 'Hands-on session on Building Agentic AI workflows with Google Gemini.',
      courseCode: 'Campus Extracurricular',
    },
    {
      id: 'task_se_srs',
      title: 'Software Engineering SRS Draft',
      type: 'project',
      durationMinutes: 90,
      dueText: 'Due in 4 days',
      deadlineHoursLeft: 96.0,
      academicImpact: 78,
      examProximityDays: 10,
      locationName: 'Computer Lab 2',
      travelTimeMinutes: 8,
      completionPercent: 30,
      details: 'Draft Use Case diagrams and sequence charts for the Semester Team Project.',
      courseCode: 'CSE 206: Software Engineering',
    },
  ],

  locations: [
    { id: 'loc_ab3', name: 'Academic Block 3', category: 'Academic', travelTimeMinutes: 0, x: 0.35, y: 0.40, desc: 'Current location. Smart classrooms.' },
    { id: 'loc_library', name: 'Central Library', category: 'Study', travelTimeMinutes: 6, x: 0.65, y: 0.28, desc: 'Quiet study zones & WiFi.' },
    { id: 'loc_lab2', name: 'Computer Lab 2', category: 'Lab', travelTimeMinutes: 8, x: 0.22, y: 0.70, desc: 'GPU workstations and Linux dev.' },
    { id: 'loc_cafe', name: 'Campus Cafeteria', category: 'Dining', travelTimeMinutes: 4, x: 0.50, y: 0.55, desc: 'Coffee & quick reset snacks.' },
    { id: 'loc_audi', name: 'Auditorium C', category: 'Events', travelTimeMinutes: 10, x: 0.80, y: 0.65, desc: 'Club sessions & symposiums.' },
  ],

  specializationProfile: {
    cgpa: 8.7,
    mathComfort: 4,
    statsComfort: 4,
    dsaKnowledge: 3,
    databaseKnowledge: 4,
    systemsKnowledge: 3,
    networkingKnowledge: 2,
    priorityInterest: 5,
    prioritySalary: 4,
    priorityFlexibility: 3,
    priorityResearch: 3,
    priorityInternational: 4,
  }
};

const DecisionEngine = {
  evaluateNextAction(availableMinutes, location, academicPriority) {
    const feasible = [];

    for (const task of AppData.tasks) {
      const totalTimeNeeded = task.durationMinutes + task.travelTimeMinutes;
      // Hard constraint: task + travel <= available time + 15 min buffer
      if (totalTimeNeeded > availableMinutes + 15) continue;

      let urgency = task.deadlineHoursLeft <= 6 ? 0.95 : task.deadlineHoursLeft <= 24 ? 0.85 : 0.65;
      let impact = task.academicImpact / 100.0;
      let examScore = task.examProximityDays <= 3 ? 0.90 : 0.60;
      
      let ratio = task.durationMinutes / availableMinutes;
      let timeFit = (ratio >= 0.6 && ratio <= 1.05) ? 0.92 : 0.70;

      let travelScore = task.travelTimeMinutes <= 4 ? 0.95 : task.travelTimeMinutes <= 8 ? 0.85 : 0.65;
      if (location && location.toLowerCase() === task.locationName.toLowerCase()) travelScore = 1.0;

      let score = (urgency * 0.35) + (impact * 0.30) + (examScore * 0.20) + (timeFit * 0.10) + (travelScore * 0.05);
      feasible.push({
        task,
        totalScore: Math.round(score * 100),
        urgency,
        impact,
        examScore,
        timeFit,
        travelScore,
      });
    }

    if (feasible.length === 0) {
      const shortest = AppData.tasks.reduce((a, b) => a.durationMinutes < b.durationMinutes ? a : b);
      feasible.push({
        task: shortest,
        totalScore: 50,
        urgency: 0.5, impact: 0.5, examScore: 0.5, timeFit: 0.5, travelScore: 0.8,
      });
    }

    feasible.sort((a, b) => b.totalScore - a.totalScore);
    const best = feasible[0];
    const alts = feasible.slice(1).map(f => f.task);

    let changeReason = '';
    if (availableMinutes <= 45) {
      changeReason = `Your available time decreased to ${availableMinutes} minutes. The full 60-min assignment would cause a schedule breach, so UNI STEP shifted to a high-yield 35-min exam revision.`;
    } else if (availableMinutes >= 150) {
      changeReason = `Your available time expanded to ${availableMinutes} minutes (2.5+ hours). You can now finish the assignment with ample buffer to attend the AI Club workshop.`;
    } else {
      changeReason = `Decision calibrated for a ${availableMinutes}-minute block at ${location}.`;
    }

    return {
      task: best.task,
      totalScore: best.totalScore,
      factors: [
        { label: 'Deadline urgency', score: best.urgency, desc: best.task.deadlineHoursLeft <= 6 ? 'Due tonight (11:59 PM)' : 'Sufficient submission window' },
        { label: 'Academic impact', score: best.impact, desc: `High credit weight in ${best.task.courseCode}` },
        { label: 'Exam relevance', score: best.examScore, desc: `Midterm exam is in only ${best.task.examProximityDays} days` },
        { label: 'Time fit', score: best.timeFit, desc: `${best.task.durationMinutes}m fits inside ${availableMinutes}m window` },
        { label: 'Travel efficiency', score: best.travelScore, desc: `${best.task.locationName} is ${best.task.travelTimeMinutes} mins away` },
      ],
      reasons: [
        `Deadline is approaching (${best.task.dueText})`,
        `${best.task.completionPercent}% already completed — low friction to finish`,
        `DBMS exam is in ${best.task.examProximityDays} days; this assignment covers key questions`,
        `You have ${availableMinutes} mins available (${best.task.durationMinutes}m task duration)`,
        `${best.task.locationName} is only ${best.task.travelTimeMinutes} minutes away`,
        `Completing it now completely clears your evening workload`,
      ],
      tradeOff: 'You will miss the AI Club event if you stay longer, but you can still attend after completing priority work if time allows.',
      gains: [
        'Zero deadline penalty risk on academic submissions',
        'Direct reinforcement for the upcoming midterm exam',
        'Significantly lower stress for the remainder of the week',
      ],
      giveUps: [
        'Extracurricular leisure and club networking time',
        'Unstructured free time in the cafeteria',
      ],
      alternatives: alts,
      changeReason,
      contextSummary: `${availableMinutes}m free • ${location} • ${academicPriority} Priority`,
    };
  },

  evaluateSpecialization(p) {
    let aimlScore = Math.round(70 + (p.priorityResearch * 2) + (p.mathComfort * 2));
    let sweScore = Math.round(68 + (p.priorityFlexibility * 3.5) + (p.dsaKnowledge * 2));
    let dataScore = Math.round(66 + (p.prioritySalary * 2) + (p.databaseKnowledge * 2));
    let cyberScore = Math.round(60 + (p.networkingKnowledge * 3));

    let tracks = [
      { id: 'aiml', title: 'AI / Machine Learning', score: aimlScore, desc: 'Your strong background in Python and comfort with Linear Algebra makes AI/ML your highest strategic alignment.' },
      { id: 'swe', title: 'Software Engineering & Systems', score: sweScore, desc: 'High flexibility pathway with massive industry demand in scalable backend services and distributed systems.' },
      { id: 'data', title: 'Data Science & Big Data', score: dataScore, desc: 'Shares statistical foundations and database strengths with high flexibility across analytics and product teams.' },
      { id: 'cyber', title: 'Cybersecurity', score: cyberScore, desc: 'Requires deeper grounding in low-level operating systems and packet inspection compared to your current profile.' },
    ];

    tracks.sort((a, b) => b.score - a.score);

    tracks[0].level = 'Strong Alignment';
    tracks[1].level = 'Also Consider';
    tracks[2].level = 'Also Consider';
    tracks[3].level = 'Different Path';

    let reason = '';
    if (p.priorityFlexibility >= 4 && tracks[0].id === 'swe') {
      reason = 'Your recommendation changed to Software Engineering because you increased the priority of Career Flexibility. Software Engineering permits broad mobility across product, fintech, and web infrastructure.';
    } else if (p.priorityResearch >= 4 && tracks[0].id === 'aiml') {
      reason = 'AI / Machine Learning strongly solidified at the top because of your high Research weight, directly supported by your Linear Algebra and mathematical foundation.';
    } else {
      reason = `Calibrated across your preferences: Interest (${p.priorityInterest}/5), Salary (${p.prioritySalary}/5), and Flexibility (${p.priorityFlexibility}/5).`;
    }

    return { tracks, changeReason: reason };
  }
};
