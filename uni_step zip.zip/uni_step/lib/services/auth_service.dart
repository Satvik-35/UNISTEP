import 'dart:async';
import '../models/student_profile.dart';
import '../data/demo_data.dart';
import '../utils/constants.dart';

abstract class AuthService {
  Future<StudentProfile?> getCurrentUser();
  Future<StudentProfile> signInWithCredentials(String usernameOrEmail, String password);
  Future<StudentProfile> registerUser({
    required String name,
    required String username,
    required String email,
    required String password,
    String? university,
    String? year,
  });
  Future<StudentProfile> signInWithDemo();
  Future<void> signOut();
  bool get isFirebaseConnected;
}

class MockAuthService implements AuthService {
  StudentProfile? _currentUser;
  final _authStateController = StreamController<StudentProfile?>.broadcast();

  MockAuthService() {
    // Start with demo user accessible
    _currentUser = DemoData.rahulProfile;
  }

  Stream<StudentProfile?> get authStateChanges => _authStateController.stream;

  @override
  bool get isFirebaseConnected => false; // Fallback to local demo mode

  @override
  Future<StudentProfile?> getCurrentUser() async {
    return _currentUser;
  }

  @override
  Future<StudentProfile> signInWithCredentials(String usernameOrEmail, String password) async {
    await Future.delayed(const Duration(milliseconds: 600)); // realistic UX timing

    final isDemoMatch = (usernameOrEmail == AppConstants.demoCredentialsUsername ||
            usernameOrEmail == 'rahul@srm.edu.in' ||
            usernameOrEmail == 'rahul') &&
        (password == AppConstants.demoCredentialsPassword || password == 'demo');

    if (isDemoMatch) {
      _currentUser = DemoData.rahulProfile;
      _authStateController.add(_currentUser);
      return _currentUser!;
    }

    // Allow user-entered credentials for hackathon testing
    if (password.length >= 6) {
      _currentUser = StudentProfile(
        id: 'user_${DateTime.now().millisecondsSinceEpoch}',
        name: usernameOrEmail.split('@').first,
        username: usernameOrEmail,
        email: usernameOrEmail.contains('@') ? usernameOrEmail : '$usernameOrEmail@campus.edu',
        university: 'SRM University AP',
        year: '2nd Year',
        cgpa: 8.5,
        interests: ['AI / Machine Learning', 'Software Engineering'],
        skills: ['Python', 'SQL', 'C++'],
      );
      _authStateController.add(_currentUser);
      return _currentUser!;
    }

    throw Exception('Invalid credentials. For quick demo, use demo / demo123');
  }

  @override
  Future<StudentProfile> signInWithDemo() async {
    await Future.delayed(const Duration(milliseconds: 300));
    _currentUser = DemoData.rahulProfile;
    _authStateController.add(_currentUser);
    return _currentUser!;
  }

  @override
  Future<StudentProfile> registerUser({
    required String name,
    required String username,
    required String email,
    required String password,
    String? university,
    String? year,
  }) async {
    await Future.delayed(const Duration(milliseconds: 600));
    _currentUser = StudentProfile(
      id: 'usr_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      username: username,
      email: email,
      university: university ?? 'University Campus',
      year: year ?? '1st Year',
      cgpa: 8.5,
      interests: ['Computer Science', 'AI'],
      skills: ['Python', 'Problem Solving'],
    );
    _authStateController.add(_currentUser);
    return _currentUser!;
  }

  @override
  Future<void> signOut() async {
    _currentUser = null;
    _authStateController.add(null);
  }
}
