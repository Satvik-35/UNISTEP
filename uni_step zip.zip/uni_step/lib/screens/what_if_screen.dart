import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../app/app_state.dart';
import '../models/decision_item.dart';
import '../engines/daily_decision_engine.dart';
import 'decision_explanation_screen.dart';

class WhatIfScreen extends StatefulWidget {
  final AppState appState;

  const WhatIfScreen({super.key, required this.appState});

  @override
  State<WhatIfScreen> createState() => _WhatIfScreenState();
}

class _WhatIfScreenState extends State<WhatIfScreen> {
  late int _simulatedMinutes;
  late String _simulatedLocation;
  late String _simulatedPriority;
  DecisionItem? _simulatedDecision;

  @override
  void initState() {
    super.initState();
    _simulatedMinutes = widget.appState.profile.currentAvailableMinutes;
    _simulatedLocation = widget.appState.profile.currentLocation;
    _simulatedPriority = widget.appState.profile.academicPriority;
    _recalculate();
  }

  void _recalculate() {
    setState(() {
      _simulatedDecision = DailyDecisionEngine.evaluateNextAction(
        tasks: widget.appState.tasks,
        profile: widget.appState.profile,
        overrideAvailableMinutes: _simulatedMinutes,
        overrideLocation: _simulatedLocation,
        overrideAcademicPriority: _simulatedPriority,
        previousRecommendationTitle: 'Complete DBMS Assignment',
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final decision = _simulatedDecision;
    final task = decision?.recommendedTask;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('WHAT-IF SIMULATION'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Simulation Banner
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppColors.whatIfGradient,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  Icon(Icons.alt_route, color: Colors.white, size: 28),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'DYNAMIC WHAT-IF ENGINE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Change your time or location below to observe how the decision intelligence adapts in real-time.',
                          style: TextStyle(color: Colors.white, fontSize: 13, height: 1.3),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // CONTROLS CONTAINER
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Time Slider
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Available Time',
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.secondaryContainer,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '$_simulatedMinutes minutes',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF0F766E),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Slider(
                    value: _simulatedMinutes.toDouble(),
                    min: 20,
                    max: 240,
                    divisions: 11,
                    activeColor: AppColors.secondary,
                    onChanged: (val) {
                      _simulatedMinutes = val.round();
                      _recalculate();
                    },
                  ),

                  // Quick presets
                  Wrap(
                    spacing: 8,
                    children: [
                      _buildPresetChip('45 mins (Quick Break)', 45),
                      _buildPresetChip('90 mins (Default)', 90),
                      _buildPresetChip('180 mins (3 Hours)', 180),
                    ],
                  ),
                  const SizedBox(height: 18),
                  const Divider(color: AppColors.border),
                  const SizedBox(height: 14),

                  // Location Selector
                  const Text(
                    'Simulated Current Location',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _simulatedLocation,
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                    ),
                    items: [
                      'Academic Block 3',
                      'Central Library',
                      'Computer Lab 2',
                      'Campus Cafeteria',
                      'Hostel Block A',
                    ].map((loc) => DropdownMenuItem(value: loc, child: Text(loc))).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        _simulatedLocation = val;
                        _recalculate();
                      }
                    },
                  ),
                  const SizedBox(height: 16),

                  // Priority Selector
                  const Text(
                    'Academic Priority Focus',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: ['High', 'Balanced', 'Extracurricular'].map((p) {
                      final isSelected = _simulatedPriority == p;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _simulatedPriority = p;
                              _recalculate();
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              color: isSelected ? AppColors.primary : AppColors.surfaceVariant,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: isSelected ? AppColors.primary : AppColors.border,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                p,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: isSelected ? Colors.white : AppColors.textSecondary,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // RECALCULATED RECOMMENDATION CARD
            if (task != null) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.secondary, width: 2),
                  boxShadow: [
                    BoxShadow(color: AppColors.secondary.withOpacity(0.12), blurRadius: 16, offset: const Offset(0, 4)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.secondaryContainer,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            'RECALCULATED NEXT STEP',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF0F766E),
                            ),
                          ),
                        ),
                        Text(
                          '${decision!.totalScore.round()}% Utility Score',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.secondary),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      task.title,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${task.durationMinutes} mins • ${task.locationName}',
                      style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 16),

                    // YOUR DECISION CHANGED BECAUSE... BANNER
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF0FDF4),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.secondaryLight),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Row(
                            children: [
                              Icon(Icons.auto_awesome, color: AppColors.secondary, size: 16),
                              SizedBox(width: 6),
                              Text(
                                'YOUR DECISION CHANGED BECAUSE...',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF166534),
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            decision.changeReason.isNotEmpty
                                ? decision.changeReason
                                : 'With $_simulatedMinutes minutes available at $_simulatedLocation, the engine pruned infeasible actions to avoid schedule conflicts.',
                            style: const TextStyle(fontSize: 13, height: 1.4, color: Color(0xFF14532D)),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),

                    ElevatedButton(
                      onPressed: () {
                        widget.appState.recalculateDailyDecision(
                          overrideAvailableMinutes: _simulatedMinutes,
                          overrideLocation: _simulatedLocation,
                          overrideAcademicPriority: _simulatedPriority,
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            backgroundColor: AppColors.secondary,
                            content: Text('Applied simulated scenario to your active daily plan!'),
                          ),
                        );
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.secondary,
                        minimumSize: const Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Apply This Simulation as Active Step', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildPresetChip(String label, int minutes) {
    final isSelected = _simulatedMinutes == minutes;
    return ActionChip(
      label: Text(label),
      backgroundColor: isSelected ? AppColors.secondaryContainer : AppColors.surfaceVariant,
      side: BorderSide(color: isSelected ? AppColors.secondary : AppColors.border),
      labelStyle: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: isSelected ? const Color(0xFF0F766E) : AppColors.textSecondary,
      ),
      onPressed: () {
        _simulatedMinutes = minutes;
        _recalculate();
      },
    );
  }
}
