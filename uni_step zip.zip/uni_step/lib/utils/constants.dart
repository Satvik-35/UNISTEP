class AppConstants {
  static const String appName = 'UNI STEP';
  static const String tagline = 'Make better decisions. Move forward.';
  static const String appDescription =
      'Your university information is scattered everywhere. UNI STEP brings it together and helps you decide what to do next.';
  
  static const String problemStatement = 'PS03 — The Next Decision';
  
  static const String disclaimerText =
      'This analysis is decision support based on the information you provided. It does not guarantee a job, salary, internship, or career outcome.';
  
  static const String demoModeNote =
      'Demo mode is active. Using local decision engine & mock campus state.';
  
  static const String demoCredentialsUsername = 'demo';
  static const String demoCredentialsPassword = 'demo123';
}
