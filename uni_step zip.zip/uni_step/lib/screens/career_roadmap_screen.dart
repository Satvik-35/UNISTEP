import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../data/specialization_data.dart';
import '../app/app_state.dart';
import '../models/specialization_model.dart';

class CareerRoadmapScreen extends StatelessWidget {
  final AppState appState;
  final SpecializationOption option;

  const CareerRoadmapScreen({
    super.key,
    required this.appState,
    required this.option,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('${option.title} Roadmap'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Sample Market Data Banner (Strict prompt requirement)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surfaceVariant,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  const Icon(Icons.analytics_outlined, size: 18, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      SpecializationCatalog.marketDataDisclaimer,
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // CAREER / JOB MARKET LAYER
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.business_center, color: AppColors.primary, size: 20),
                      SizedBox(width: 8),
                      Text(
                        'MARKET PROFILE & ENTRY ROLES',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 0.5, color: AppColors.textPrimary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  const Text('Common Job Titles:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: option.marketRoles.map((r) => _buildBadge(r, AppColors.primaryContainer, AppColors.onPrimaryContainer)).toList(),
                  ),
                  const SizedBox(height: 14),

                  const Text('Core Technologies & Frameworks:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: option.technologies.map((t) => _buildBadge(t, AppColors.surfaceVariant, AppColors.textPrimary)).toList(),
                  ),
                  const SizedBox(height: 14),

                  const Text('Entry-Level Competency Expectations:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
                  const SizedBox(height: 4),
                  Text(
                    option.entryLevelExpectations,
                    style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // PERSONALIZED 6-MONTH ROADMAP TIMELINE
            const Text(
              'YOUR 6-MONTH STRATEGIC ROADMAP',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 14),

            ...option.roadmap.asMap().entries.map((entry) {
              final idx = entry.key;
              final stage = entry.value;
              final isLast = idx == option.roadmap.length - 1;

              return IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Timeline Node & Line
                    Column(
                      children: [
                        Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                            boxShadow: [
                              BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 6),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              '${idx + 1}',
                              style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        if (!isLast)
                          Expanded(
                            child: Container(
                              width: 2,
                              color: AppColors.border,
                              margin: const EdgeInsets.symmetric(vertical: 4),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(width: 14),

                    // Roadmap Stage Content Card
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: AppColors.primaryContainer,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    stage.period,
                                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.onPrimaryContainer),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              stage.title,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                            ),
                            const SizedBox(height: 10),

                            // Focus Skills
                            _buildRoadmapRow(Icons.psychology, 'Focus Skills', stage.skills.join(', ')),
                            const SizedBox(height: 6),
                            // Key Projects
                            _buildRoadmapRow(Icons.code, 'Project Target', stage.projects.join('; ')),
                            const SizedBox(height: 6),
                            // Recommended Course
                            _buildRoadmapRow(Icons.school, 'Course Track', stage.courses.join('; ')),
                            const SizedBox(height: 6),
                            // Portfolio Deliverable
                            _buildRoadmapRow(Icons.verified, 'Milestone', stage.portfolioDeliverable),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildBadge(String text, Color bg, Color textCol) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: textCol),
      ),
    );
  }

  Widget _buildRoadmapRow(IconData icon, String label, String val) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 14, color: AppColors.primary),
        const SizedBox(width: 6),
        Text('$label: ', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        Expanded(
          child: Text(
            val,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ),
      ],
    );
  }
}
